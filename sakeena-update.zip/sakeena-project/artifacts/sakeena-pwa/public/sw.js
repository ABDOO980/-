const CACHE = 'sakeena-shell-v4';
const APP_SHELL = ['/', '/index.html', '/manifest.webmanifest', '/favicon.svg', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', (event) => {
  let data = { title: 'سَكينة', body: '' };
  try { data = event.data ? event.data.json() : data; } catch { /* non-JSON payload, ignore */ }
  event.waitUntil(
    self.registration.showNotification(data.title || 'سَكينة', {
      body: data.body || '',
      icon: '/icon-192.png',
      badge: '/favicon.svg',
      dir: 'rtl',
      lang: 'ar',
      data: { url: data.url || '/' },
    }),
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(async (clients) => {
      const existing = clients.find((client) => 'focus' in client);
      if (existing) {
        if ('navigate' in existing) { try { await existing.navigate(target); } catch { /* cross-origin or unsupported */ } }
        return existing.focus();
      }
      return self.clients.openWindow(target);
    }),
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.hostname.includes('api.aladhan.com')) {
    event.respondWith(networkFirst(request));
  } else if (url.hostname.includes('api.alquran.cloud')) {
    event.respondWith(networkFirst(request));
  } else if (url.hostname.endsWith('mp3quran.net') && url.pathname.endsWith('.mp3')) {
    event.respondWith(audioHandler(request));
  } else if (url.hostname.includes('download.quranicaudio.com')) {
    event.respondWith(cacheFirst(request));
  } else if (url.origin === self.location.origin) {
    event.respondWith(appShellFirst(request));
  }
});

async function networkFirst(request) {
  const cache = await caches.open(CACHE);
  try {
    const response = await fetch(request);
    if (response.ok) await cache.put(request, response.clone());
    return response;
  } catch {
    return (await cache.match(request)) || new Response('Offline', { status: 503 });
  }
}

async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response.ok) (await caches.open(CACHE)).put(request, response.clone());
  return response;
}

async function appShellFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response.ok) (await caches.open(CACHE)).put(request, response.clone());
    return response;
  } catch {
    if (request.mode === 'navigate') {
      return (await caches.match('/index.html')) || new Response('Offline', { status: 503 });
    }
    throw new Error('Offline resource unavailable');
  }
}
// Quran audio. Anything already cached (a surah the user downloaded, or the
// one currently playing) is served from cache, including Range requests the
// <audio> element makes for seeking. Only ONE streamed surah is kept in
// 'sakeena-audio-current': when a new surah starts streaming, the previous
// one is evicted, so streaming never grows storage. Downloads live in the
// separate 'sakeena-audio-downloads' cache, which is never evicted here.
const AUDIO_CURRENT = 'sakeena-audio-current';

async function audioHandler(request) {
  const cached = await caches.match(request.url);
  if (cached) return rangeFromCache(request, cached);
  // Only the <audio> element's own streaming requests get cached here; a
  // programmatic fetch (the explicit download) is handled by the page.
  if (request.destination !== 'audio') return fetch(request);
  try {
    const full = await fetch(request.url); // fetch the whole file: 206 responses can't be cached
    if (!full.ok) return fetch(request);
    const cache = await caches.open(AUDIO_CURRENT);
    for (const key of await cache.keys()) await cache.delete(key);
    await cache.put(request.url, full.clone());
    return rangeFromCache(request, full);
  } catch {
    return fetch(request);
  }
}

async function rangeFromCache(request, response) {
  const range = request.headers.get('range');
  if (!range) return response;
  const match = /bytes=(\d+)-(\d*)/.exec(range);
  if (!match) return response;
  const buffer = await response.arrayBuffer();
  const start = Number(match[1]);
  const end = match[2] ? Math.min(Number(match[2]), buffer.byteLength - 1) : buffer.byteLength - 1;
  return new Response(buffer.slice(start, end + 1), {
    status: 206,
    headers: {
      'Content-Type': response.headers.get('Content-Type') || 'audio/mpeg',
      'Content-Range': `bytes ${start}-${end}/${buffer.byteLength}`,
      'Content-Length': String(end - start + 1),
    },
  });
}
