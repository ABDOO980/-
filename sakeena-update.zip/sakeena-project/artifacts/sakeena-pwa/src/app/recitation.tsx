import { ArrowRight, Mic, Square } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { Link } from 'wouter';
import { type QuranVerse, readingVerses, surahs, fetchSurahVerses } from '@/lib/sakeena';

export type RecitationRecognition = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: unknown) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

export function RecitationPage() {
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [notice, setNotice] = useState('');
  const [selectedSurahId, setSelectedSurahId] = useState(1);
  const [verses, setVerses] = useState<QuranVerse[]>(readingVerses);
  const [versesVisible, setVersesVisible] = useState(false);
  const [loadingVerses, setLoadingVerses] = useState(false);
  const recognitionRef = useRef<RecitationRecognition | null>(null);
  const selectedSurah = surahs.find((surah) => surah.id === selectedSurahId) ?? surahs[0];
  const recognitionConstructor = typeof window === 'undefined' ? undefined : (window as unknown as {
    SpeechRecognition?: new () => RecitationRecognition;
    webkitSpeechRecognition?: new () => RecitationRecognition;
  }).SpeechRecognition ?? (window as unknown as {
    webkitSpeechRecognition?: new () => RecitationRecognition;
  }).webkitSpeechRecognition;

  useEffect(() => () => {
    recognitionRef.current?.stop();
  }, []);

  useEffect(() => {
    let cancelled = false;
    setVersesVisible(false);
    setTranscript('');
    setLoadingVerses(true);
    setNotice('');
    if (selectedSurahId === 1) {
      setVerses(readingVerses);
      setLoadingVerses(false);
      return () => { cancelled = true; };
    }
    void fetchSurahVerses(selectedSurahId).then((result) => {
      if (!cancelled) setVerses(result);
    }).catch(() => {
      if (!cancelled) {
        setVerses([]);
        setNotice('تعذر تحميل آيات السورة الآن. تحقق من الاتصال ثم اختر السورة مرة أخرى.');
      }
    }).finally(() => {
      if (!cancelled) setLoadingVerses(false);
    });
    return () => { cancelled = true; };
  }, [selectedSurahId]);

  const stopListening = () => {
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    setListening(false);
  };

  const startListening = () => {
    if (!recognitionConstructor) {
      setNotice('المتصفح الحالي لا يدعم الاستماع للتسميع. جرّب Chrome أو Edge واسمح بالميكروفون.');
      return;
    }
    setTranscript('');
    setNotice('');
    const recognition = new recognitionConstructor();
    recognition.lang = 'ar-SA';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.onresult = (event) => {
      const result = event as { results?: { length: number; [index: number]: { [index: number]: { transcript?: string } } } };
      const results = result.results;
      if (!results) return;
      let text = '';
      for (let index = 0; index < results.length; index += 1) text += results[index]?.[0]?.transcript ?? '';
      setTranscript(text.trim());
    };
    recognition.onend = () => {
      recognitionRef.current = null;
      setListening(false);
    };
    recognitionRef.current = recognition;
    recognition.start();
    setListening(true);
  };

  const beginRecitation = () => {
    setVersesVisible(false);
    startListening();
  };

  return (
    <div className="rise-in mx-auto max-w-3xl">
      <div className="mb-6 flex items-center justify-between gap-3">
        <Link href="/more" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-accent"><ArrowRight size={17} />كل الأدوات</Link>
        <span className="rounded-full border border-accent/35 px-3 py-1.5 text-[10px] text-accent">حفظ ومتابعة</span>
      </div>
      <section className="featured-card rounded-[2rem] border bg-card p-7 md:p-10">
        <span className="mb-6 grid size-14 place-items-center rounded-2xl bg-accent text-accent-foreground"><Mic size={25} /></span>
        <p className="mb-2 text-xs font-semibold tracking-[.16em] text-accent">تسميع · رتل بصوتك</p>
        <h1 className="font-arabic text-4xl">سمّع السورة بصوتك</h1>
        <p className="mt-4 max-w-xl text-sm leading-7 text-muted-foreground">اختر السورة، راجع الآيات عند الحاجة، ثم أخفها وابدأ التسميع من الذاكرة.</p>
        <label className="mt-6 block text-xs text-muted-foreground">
          السورة
          <select value={selectedSurahId} onChange={(event) => setSelectedSurahId(Number(event.target.value))} className="mt-2 w-full rounded-xl border border-input bg-background px-3 py-3 text-sm text-foreground">
            {surahs.map((surah) => <option key={surah.id} value={surah.id}>سورة {surah.name}</option>)}
          </select>
        </label>
        <div className="mt-7 rounded-2xl border border-accent/30 bg-secondary/45 p-5">
          <div className="mb-3 flex items-center justify-between gap-3">
            <p className="text-xs text-accent">{versesVisible ? `آيات سورة ${selectedSurah.name}` : 'الآيات مخفية للتسميع'}</p>
            <button onClick={() => setVersesVisible((visible) => !visible)} disabled={loadingVerses || !verses.length} className="rounded-lg border border-accent/35 px-3 py-2 text-[10px] font-semibold text-accent disabled:opacity-50">
              {versesVisible ? 'إخفاء الآيات' : 'إظهار الآيات'}
            </button>
          </div>
          {loadingVerses
            ? <p className="py-8 text-center text-xs text-muted-foreground">جاري تحميل الآيات…</p>
            : versesVisible
              ? <p className="font-arabic text-2xl leading-[2]">{verses.map((verse) => verse.arabic).join(' ')}</p>
              : <div className="grid min-h-36 place-items-center rounded-xl border border-dashed border-accent/30 p-5 text-center text-sm leading-7 text-muted-foreground">الآيات غير ظاهرة الآن.<br />أظهرها للمراجعة، ثم أخفها قبل التسميع.</div>}
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          {!listening
            ? <button onClick={beginRecitation} disabled={loadingVerses || !verses.length} className="flex items-center gap-2 rounded-xl bg-primary px-5 py-3 text-xs font-bold text-primary-foreground disabled:opacity-50"><Mic size={16} />ابدأ التسميع</button>
            : <button onClick={stopListening} className="flex items-center gap-2 rounded-xl bg-destructive px-5 py-3 text-xs font-bold text-destructive-foreground"><Square size={14} fill="currentColor" />أوقف التسميع</button>}
          <button onClick={() => setTranscript('')} className="rounded-xl border border-border px-5 py-3 text-xs font-semibold text-muted-foreground">مسح النص</button>
        </div>
        {transcript && <div className="mt-5 rounded-2xl border border-border bg-background p-4"><p className="mb-2 text-xs text-accent">ما التقطه الميكروفون</p><p className="font-arabic text-lg leading-9">{transcript}</p></div>}
        {notice && <p className="mt-4 rounded-xl bg-secondary p-3 text-xs leading-6 text-muted-foreground">{notice}</p>}
      </section>
    </div>
  );
}
