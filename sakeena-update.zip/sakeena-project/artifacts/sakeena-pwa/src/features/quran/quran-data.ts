import { readStorage, surahs as fallbackSurahs, writeStorage, type QuranVerse } from '@/lib/sakeena';

export type QuranSurah = {
  number: number;
  name: string;
  englishName: string;
  numberOfAyahs: number;
  revelationType: string;
};

export type QuranVerseDetail = QuranVerse & {
  translation?: string;
  tafsir?: string;
  surah?: number;
};

const CATALOG_KEY = 'sakeena.quran.catalog.v1';
const CACHE_PREFIX = 'sakeena.quran.content.v1.';

// Streaming source: mp3quran.net (public API v3, Hafs 'an 'Asim riwayah).
// Every server URL below was read directly from
// https://www.mp3quran.net/api/v3/reciters and confirmed to cover all 114
// surahs (no silent fallback needed for any of the five).
export type Reciter = { id: string; label: string; server: string };

export const reciters: Reciter[] = [
  { id: 'mishary', label: 'مشاري راشد العفاسي', server: 'https://server8.mp3quran.net/afs/' },
  { id: 'maher', label: 'ماهر المعيقلي', server: 'https://server12.mp3quran.net/maher/' },
  { id: 'basit', label: 'عبد الباسط عبد الصمد', server: 'https://server7.mp3quran.net/basit/' },
  { id: 'sudais', label: 'عبد الرحمن السديس (إمام الحرم المكي)', server: 'https://server11.mp3quran.net/sds/' },
  { id: 'budair', label: 'صلاح البدير (إمام الحرم النبوي)', server: 'https://server6.mp3quran.net/s_bud/' },
];

export function recitationUrl(surahId: number, reciterId: string) {
  const reciter = reciters.find((item) => item.id === reciterId) ?? reciters[0];
  return `${reciter.server}${String(surahId).padStart(3, '0')}.mp3`;
}

const DOWNLOADS_KEY = 'sakeena.quran.downloads.v1';

function downloadKey(surahId: number, reciterId: string) {
  return `${reciterId}-${surahId}`;
}

export function isSurahDownloaded(surahId: number, reciterId: string) {
  const downloaded = readStorage<string[]>(DOWNLOADS_KEY, []);
  return downloaded.includes(downloadKey(surahId, reciterId));
}

// Streaming playback is cached by the service worker in a cache that keeps
// ONLY the surah currently playing (see public/sw.js). A surah the user
// explicitly downloads is copied into this separate, persistent cache, which
// the service worker never evicts.
const DOWNLOADS_CACHE = 'sakeena-audio-downloads';

export async function downloadSurahForOffline(surahId: number, reciterId: string) {
  const url = recitationUrl(surahId, reciterId);
  const response = await fetch(url);
  if (!response.ok) throw new Error('تعذر تحميل التلاوة.');
  const cache = await caches.open(DOWNLOADS_CACHE);
  await cache.put(url, response.clone());
  await response.arrayBuffer();
  const downloaded = readStorage<string[]>(DOWNLOADS_KEY, []);
  const key = downloadKey(surahId, reciterId);
  if (!downloaded.includes(key)) writeStorage(DOWNLOADS_KEY, [...downloaded, key]);
}

export async function removeDownloadedSurah(surahId: number, reciterId: string) {
  const key = downloadKey(surahId, reciterId);
  const downloaded = readStorage<string[]>(DOWNLOADS_KEY, []);
  writeStorage(DOWNLOADS_KEY, downloaded.filter((item) => item !== key));
  try {
    const cache = await caches.open(DOWNLOADS_CACHE);
    await cache.delete(recitationUrl(surahId, reciterId));
  } catch { /* cache API unavailable */ }
}

// ---- Text content (alquran.cloud public API) -------------------------------
const API = 'https://api.alquran.cloud/v1';

export type QuranAyahHit = {
  number: number;
  numberInSurah: number;
  text: string;
  surah: { number: number; name: string };
};

async function getJson<T>(path: string): Promise<T> {
  const response = await fetch(`${API}${path}`);
  if (!response.ok) throw new Error(`Quran request failed (${response.status})`);
  const json = await response.json();
  if (json?.data === undefined) throw new Error('Quran response was empty');
  return json.data as T;
}

function fallbackCatalog(): QuranSurah[] {
  return fallbackSurahs.map((item) => ({
    number: item.id,
    name: item.name,
    englishName: item.latin,
    numberOfAyahs: item.verses,
    revelationType: item.place === 'مكية' ? 'Meccan' : 'Medinan',
  }));
}

// Surah list: network first, then the last saved copy, then the small built-in list.
export async function fetchQuranCatalog(): Promise<QuranSurah[]> {
  try {
    const data = await getJson<QuranSurah[]>('/surah');
    const list = data.map((s) => ({
      number: s.number,
      name: s.name,
      englishName: s.englishName,
      numberOfAyahs: s.numberOfAyahs,
      revelationType: s.revelationType,
    }));
    if (list.length) {
      try { writeStorage(CATALOG_KEY, list); } catch { /* storage full */ }
      return list;
    }
  } catch { /* offline — fall through */ }
  const saved = readStorage<QuranSurah[]>(CATALOG_KEY, []);
  return saved.length ? saved : fallbackCatalog();
}

type EditionAyah = { numberInSurah: number; text: string };
type Edition = { ayahs: EditionAyah[] };

// One surah with Uthmani text, English translation (Sahih International) and
// Arabic tafsir (Al-Muyassar). Saved for offline reading after each success.
export async function fetchQuranContent(surahId: number): Promise<{ verses: QuranVerseDetail[]; cached: boolean }> {
  try {
    const editions = await getJson<Edition[]>(`/surah/${surahId}/editions/quran-uthmani,en.sahih,ar.muyassar`);
    const [arabic, english, tafsir] = editions;
    const verses: QuranVerseDetail[] = (arabic?.ayahs ?? []).map((ayah, index) => ({
      id: ayah.numberInSurah,
      arabic: ayah.text,
      translation: english?.ayahs?.[index]?.text,
      tafsir: tafsir?.ayahs?.[index]?.text,
      surah: surahId,
    })).filter((verse) => verse.id > 0 && verse.arabic);
    if (!verses.length) throw new Error('Quran response was empty');
    try { writeStorage(`${CACHE_PREFIX}${surahId}`, verses); } catch { /* storage full */ }
    return { verses, cached: false };
  } catch {
    const saved = readStorage<QuranVerseDetail[]>(`${CACHE_PREFIX}${surahId}`, []);
    return { verses: saved, cached: saved.length > 0 };
  }
}

export async function fetchJuz(juz: number): Promise<QuranAyahHit[]> {
  const data = await getJson<{ ayahs: QuranAyahHit[] }>(`/juz/${juz}/quran-uthmani`);
  return data.ayahs ?? [];
}

export async function searchQuran(query: string): Promise<QuranAyahHit[]> {
  const data = await getJson<{ matches?: QuranAyahHit[] }>(`/search/${encodeURIComponent(query)}/all/quran-uthmani`);
  return (data.matches ?? []).slice(0, 50);
}
