import { Check } from 'lucide-react';
import { useStoredState } from '@/app/common';
import { Accordion, PageFrame, type Item } from './PageFrame';

const prophets: Item[] = [
  { title: 'آدم عليه السلام', subtitle: 'أبو البشر', body: 'خلق الله آدم من طين وأسجد له الملائكة، وأسكنه الجنة هو وزوجه، ونهاهما عن الأكل من شجرة واحدة. فأكلا منها بعد وسوسة الشيطان، ثم تابا إلى الله فتاب عليهما وأنزلهما إلى الأرض.', lesson: 'الخطأ طبيعي في الإنسان، والتوبة السريعة باب مفتوح دائمًا.' },
  { title: 'نوح عليه السلام', subtitle: 'الصبر على الدعوة', body: 'دعا نوح قومه إلى عبادة الله مدة طويلة جدًا فلم يؤمن معه إلا قليل. فأمره الله أن يصنع السفينة، وحين جاء الطوفان نجّاه الله ومن آمن معه، وأهلك المكذبين.', lesson: 'الثبات على الحق وإن قلّ أتباعه، والنجاة لمن أطاع الله.' },
  { title: 'إبراهيم عليه السلام', subtitle: 'خليل الرحمن', body: 'دعا إبراهيم قومه إلى ترك الأصنام وحطّمها، فألقوه في النار فجعلها الله بردًا وسلامًا عليه. ورزقه الله إسماعيل وإسحاق، ورفع هو وإسماعيل قواعد الكعبة. وابتلاه الله بأمر ذبح ابنه، فلما أسلما لأمر الله فداه الله بذبح عظيم.', lesson: 'التسليم لأمر الله والتوكل عليه في الشدائد.' },
  { title: 'يوسف عليه السلام', subtitle: 'أحسن القصص', body: 'رأى يوسف رؤيا في صغره، وحسده إخوته فألقوه في البئر، فالتقطته قافلة وبيع في مصر. ثبت على العفة أمام الفتنة ودخل السجن ظلمًا، ثم جعله الله على خزائن مصر، وجمع الله شمله بأبيه وإخوته وعفا عنهم.', lesson: 'العفة والصبر والعفو عند المقدرة، والعاقبة للمتقين.' },
  { title: 'موسى عليه السلام', subtitle: 'كليم الله', body: 'وُلد موسى في زمن فرعون الذي كان يستضعف بني إسرائيل، فحفظه الله وتربى في قصر فرعون. ثم كلّمه الله وأرسله إلى فرعون وقومه بالآيات، فلما خرج ببني إسرائيل شقّ الله لهم البحر ونجّاهم وأغرق فرعون وجنوده.', lesson: 'الله ينصر عباده المستضعفين، ولا يغلب الظالم مهما بلغ جبروته.' },
  { title: 'يونس عليه السلام', subtitle: 'ذو النون', body: 'غادر يونس قومه غاضبًا قبل أن يأذن الله له، فابتلعه الحوت. فنادى في الظلمات أن لا إله إلا أنت سبحانك إني كنت من الظالمين، فنجّاه الله وأرسله إلى قوم آمنوا به.', lesson: 'الدعاء في الشدة والاعتراف بالتقصير سبب للفرج.' },
  { title: 'أيوب عليه السلام', subtitle: 'مثل الصبر', body: 'ابتلاه الله في جسده وماله وأهله مدة طويلة فصبر ولم يشتكِ لغير الله. ثم دعا ربه أني مسّني الضر وأنت أرحم الراحمين، فكشف الله ضرّه ورزقه الخير وعوّضه.', lesson: 'الصبر الجميل لا يضيع أجره، والفرج يأتي بعد الشدة.' },
  { title: 'عيسى عليه السلام', subtitle: 'عبد الله ورسوله', body: 'وُلد عيسى من مريم العذراء بأمر الله من غير أب، وتكلّم في المهد ليبرّئ أمه. وأيّده الله بمعجزات بإذنه، منها إبراء الأكمه والأبرص وإحياء الموتى، ودعا بني إسرائيل إلى عبادة الله وحده.', lesson: 'الله على كل شيء قدير، والأنبياء كلهم جاؤوا بالتوحيد.' },
];

const companions: Item[] = [
  { title: 'أبو بكر الصديق', subtitle: 'أول الخلفاء الراشدين', body: 'من أوائل من آمنوا بالنبي ﷺ وصدّقه دائمًا، ورافقه في الهجرة وكان معه في الغار. تولّى الخلافة بعد وفاة النبي ﷺ، وثبّت الأمة في فتنة الردة، وأمر بجمع القرآن في مصحف واحد.' },
  { title: 'عمر بن الخطاب', subtitle: 'الفاروق', body: 'أسلم فعزّ الإسلام بإسلامه. تولّى الخلافة بعد أبي بكر، واشتهر بالعدل وشدة محاسبة نفسه وولاته، وفُتحت في عهده بلاد واسعة، وأُرّخ بالهجرة في عهده.' },
  { title: 'عثمان بن عفان', subtitle: 'ذو النورين', body: 'اشتهر بالحياء والكرم، وجهّز جيش العسرة بماله، واشترى بئر رومة وجعلها للمسلمين. وفي خلافته جُمع الناس على مصحف واحد.' },
  { title: 'علي بن أبي طالب', subtitle: 'رابع الخلفاء الراشدين', body: 'ابن عم النبي ﷺ وزوج فاطمة رضي الله عنها، ونشأ في بيت النبوة، وأسلم صغيرًا. اشتهر بالشجاعة والعلم والزهد، وتولّى الخلافة بعد عثمان.' },
  { title: 'بلال بن رباح', subtitle: 'مؤذن رسول الله ﷺ', body: 'كان عبدًا في مكة فعُذّب على إسلامه وهو يردد «أحد أحد»، ثم اشتراه أبو بكر وأعتقه. كان أول مؤذن في الإسلام.' },
  { title: 'خديجة بنت خويلد', subtitle: 'أم المؤمنين', body: 'أول من آمن بالنبي ﷺ، ووقفت معه بمالها ونفسها في بداية الدعوة وثبّتته حين جاءه الوحي. وكانت تاجرة معروفة بالأمانة.' },
  { title: 'عائشة بنت أبي بكر', subtitle: 'أم المؤمنين', body: 'من أكثر الصحابة روايةً للحديث، ومن أفقه نساء الأمة. كان كبار الصحابة يرجعون إليها في مسائل العلم.' },
  { title: 'سلمان الفارسي', subtitle: 'الباحث عن الحق', body: 'خرج من بلاد فارس يبحث عن الحق وقطع رحلة طويلة حتى وصل المدينة وأسلم. أشار على المسلمين بحفر الخندق في غزوة الأحزاب.' },
  { title: 'مصعب بن عمير', subtitle: 'أول سفير في الإسلام', body: 'ترك نعيم الغنى من أجل دينه، وبعثه النبي ﷺ إلى المدينة يعلّم أهلها القرآن، فأسلم على يديه عدد كبير من أهلها قبل الهجرة.' },
  { title: 'خالد بن الوليد', subtitle: 'سيف الله', body: 'قائد عسكري بارع أسلم قبل فتح مكة، وقاد المسلمين في معارك كبيرة منها اليرموك. لُقّب بسيف الله.' },
];

export function ProphetsStoriesPage() {
  return <PageFrame title="قصص الأنبياء" intro="ملخصات مبسّطة لقصص الأنبياء كما وردت في القرآن الكريم. للتوسع راجع كتب التفسير وقصص الأنبياء."><Accordion items={prophets} testId="button-prophet" /></PageFrame>;
}

export function CompanionsPage() {
  return <PageFrame title="الصحابة" intro="نبذ قصيرة عن بعض الصحابة الكرام رضي الله عنهم."><Accordion items={companions} testId="button-companion" /></PageFrame>;
}

const dailySunan = [
  'السواك عند الوضوء وقبل الصلاة', 'أذكار الصباح والمساء', 'ركعتا سنة الفجر قبل الصلاة',
  'السنن الرواتب مع الفرائض', 'صلاة الضحى ولو ركعتين', 'إفشاء السلام على من تعرف ومن لا تعرف',
  'الابتسامة في وجه أخيك', 'أذكار النوم والوضوء قبله', 'الوتر قبل النوم', 'الدعاء بين الأذان والإقامة',
];
const weekdaySunan: Record<number, string> = {
  0: '', 1: 'صيام يوم الاثنين', 2: '', 3: '', 4: 'صيام يوم الخميس',
  5: 'يوم الجمعة: الغسل والتطيّب والتبكير للمسجد، وقراءة سورة الكهف، والإكثار من الصلاة على النبي ﷺ',
  6: '',
};

const todayKey = () => new Date().toISOString().slice(0, 10);

export function SunanTodayPage() {
  const key = todayKey();
  const [done, setDone] = useStoredState<Record<string, string[]>>('sakeena.sunan', {});
  const list = [weekdaySunan[new Date().getDay()], ...dailySunan].filter(Boolean);
  const today = done[key] ?? [];
  const toggle = (item: string) => setDone((current) => {
    const set = new Set(current[key] ?? []);
    if (set.has(item)) set.delete(item); else set.add(item);
    return { [key]: [...set] };
  });
  return (
    <PageFrame title="سنن اليوم" intro="اختر سنة أو أكثر تحييها اليوم، وسجّل ما واظبت عليه.">
      <div className="mb-4 rounded-[1.25rem] bg-primary p-4 text-primary-foreground"><div className="flex justify-between text-sm"><span>أحييت اليوم</span><strong>{today.length} / {list.length}</strong></div></div>
      <div className="space-y-2">
        {list.map((item) => {
          const on = today.includes(item);
          return (
            <button key={item} type="button" onClick={() => toggle(item)} className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-right ${on ? 'border-accent bg-accent/15' : 'border-card-border bg-card'}`}>
              <span className={`grid size-6 shrink-0 place-items-center rounded-full border ${on ? 'border-accent bg-accent text-accent-foreground' : 'border-card-border'}`}>{on && <Check size={14} />}</span>
              <span className="leading-7">{item}</span>
            </button>
          );
        })}
      </div>
    </PageFrame>
  );
}

const goodDeeds = [
  'صدقة ولو قليلة', 'صلة رحم بمكالمة أو زيارة', 'برّ الوالدين والدعاء لهما', 'إماطة الأذى عن الطريق',
  'كلمة طيبة لمن حولك', 'الإصلاح بين متخاصمين', 'إطعام جائع أو إفطار صائم', 'زيارة مريض أو الاتصال به',
  'تعليم علم نافع لغيرك', 'مساعدة محتاج بجهدك', 'الدعاء لأخيك بظهر الغيب', 'التبسّم والتهلل في وجه الناس',
  'سقيا الماء أو المساهمة في سقيا', 'ستر عيب أخيك وعدم إفشائه',
];

export function GoodDeedsPage() {
  const key = todayKey();
  const [done, setDone] = useStoredState<Record<string, string[]>>('sakeena.goodDeeds', {});
  const [total, setTotal] = useStoredState<number>('sakeena.goodDeeds.total', 0);
  const today = done[key] ?? [];
  const toggle = (item: string) => {
    const has = today.includes(item);
    setDone((current) => ({ [key]: has ? today.filter((x) => x !== item) : [...today, item] }));
    setTotal((count) => Math.max(0, count + (has ? -1 : 1)));
  };
  return (
    <PageFrame title="دليل الخير" intro="أفكار بسيطة لأعمال الخير اليومية. اختر ما فعلته اليوم.">
      <div className="mb-4 grid grid-cols-2 gap-3 text-center">
        <div className="rounded-[1.1rem] bg-primary p-3 text-primary-foreground"><p className="text-xs opacity-80">اليوم</p><strong className="text-2xl">{today.length}</strong></div>
        <div className="rounded-[1.1rem] border border-accent bg-card p-3"><p className="text-xs text-muted-foreground">إجمالي أعمالك</p><strong className="text-2xl text-accent">{total}</strong></div>
      </div>
      <div className="space-y-2">
        {goodDeeds.map((item) => {
          const on = today.includes(item);
          return (
            <button key={item} type="button" onClick={() => toggle(item)} className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-right ${on ? 'border-accent bg-accent/15' : 'border-card-border bg-card'}`}>
              <span className={`grid size-6 shrink-0 place-items-center rounded-full border ${on ? 'border-accent bg-accent text-accent-foreground' : 'border-card-border'}`}>{on && <Check size={14} />}</span>
              <span className="leading-7">{item}</span>
            </button>
          );
        })}
      </div>
    </PageFrame>
  );
}

const inheritance: Item[] = [
  { title: 'قبل تقسيم التركة', body: 'يُبدأ أولًا بتجهيز الميت ودفنه، ثم سداد ديونه، ثم تنفيذ وصيته في حدود الثلث لغير الوارث، وما بقي يُقسّم على الورثة.' },
  { title: 'الزوج', body: 'له النصف إذا لم يكن للمتوفاة ولد، ويكون له الربع إذا كان لها ولد.' },
  { title: 'الزوجة', body: 'لها الربع إذا لم يكن للمتوفى ولد، ويكون لها الثمن إذا كان له ولد. وإن تعددت الزوجات اشتركن في هذا النصيب.' },
  { title: 'الأم', body: 'لها السدس إذا كان للمتوفى ولد أو جمع من الإخوة، وفي غير ذلك لها الثلث.' },
  { title: 'الأب', body: 'له السدس إذا كان للمتوفى ولد ذكر، وإذا لم يكن له ولد ورث الأب الباقي بالتعصيب.' },
  { title: 'البنت', body: 'للواحدة المنفردة النصف، وللبنتين فأكثر الثلثان. وإذا كان معها ابن فللذكر مثل حظ الأنثيين.' },
  { title: 'الابن', body: 'يرث بالتعصيب، أي يأخذ ما بقي بعد أصحاب الفروض، وإذا اجتمع مع البنات فللذكر مثل حظ الأنثيين.' },
];

export function InheritancePage() {
  return (
    <PageFrame title="المواريث" intro="تعريف مختصر بأنصبة أشهر الورثة في الشريعة. وللتقسيم الفعلي لا بد من الرجوع إلى المحكمة الشرعية أو أهل العلم، فالحالات تتغير بحسب الورثة الموجودين.">
      <Accordion items={inheritance} testId="button-inheritance" />
    </PageFrame>
  );
}
