import { useEffect } from 'react';
import { Switch, Route } from 'wouter';
import { registerSakeenaServiceWorker } from '@/lib/sakeena';
import WeeklyChallengePage from '@/features/quiz-battles/WeeklyChallengePage';
import QuizRoomPage from '@/features/quiz-battles/QuizRoomPage';
import AdminPage from '@/features/admin/AdminPage';
import GroupKhatmahPage from '@/features/khatmah/GroupKhatmahPage';
import { PersistQueryClientProvider } from '@tanstack/react-query-persist-client';
import { queryClient, sakeenaPersister } from '@/lib/query-client';
import { ErrorBoundary } from '@/components/error-boundary';
import { TooltipProvider, Toaster } from '@workspace/ui';
import NotFound from '@/pages/not-found';
import { QuranReaderPage, QuranHub } from '@/features/quran/QuranFeaturePage';
import TrackerPage from '@/features/tracker/TrackerPage';
import ArticlesPage from '@/features/articles/ArticlesPage';
import HadithPage from '@/features/hadith/HadithPage';
import CalendarPage from '@/features/calendar/CalendarPage';
import BackupPage from '@/features/backup/BackupPage';
import ShareCardPage from '@/features/share/ShareCardPage';
import LearningPage from '@/features/learning/LearningPage';
import DuaWallPage from '@/features/duas/DuaWallPage';
import RadioPage from '@/features/radio/RadioPage';
import RamadanPage from '@/features/ramadan/RamadanPage';
import FatwaPage from '@/features/fatwas/FatwaPage';
import MosquesPage from '@/features/mosques/MosquesPage';
import DailyProvisionPage from '@/features/daily/DailyProvisionPage';
import NamesOfAllahPage from '@/features/names/NamesOfAllahPage';
import RuqyahPage from '@/features/ruqyah/RuqyahPage';
import KidsCornerPage from '@/features/family/KidsCornerPage';
import BinBazPage from '@/features/binbaz/BinBazPage';
import ZakatPage from '@/features/fiqh/ZakatPage';
import { HajjBagPage, TawafCounterPage } from '@/features/hajj/HajjPages';
import { HajjGuidePage, HaramPage, LodgingPage, UmrahGuidePage } from '@/features/hajj/GuidePages';
import { CompanionsPage, GoodDeedsPage, InheritancePage, ProphetsStoriesPage, SunanTodayPage } from '@/features/knowledge/KnowledgePages';
import { Shell } from '@/app/layout';
import { Home, SpiritualPeace } from '@/app/home';
import { Adhkar, DhikrReader } from '@/app/adhkar';
import { RecitationPage } from '@/app/recitation';
import { DownloadsToolPage, MemorizationToolPage, ReflectionsToolPage, ReviewToolPage, TajweedToolPage, ToolScreen } from '@/app/tools';
import { Quiz } from '@/app/quiz';
import { Ambassadors } from '@/app/ambassadors';
import { Qibla } from '@/app/qibla';
import { More } from '@/app/more';
import { SettingsPage } from '@/app/settings';
import { About } from '@/app/about';

 function Router() {
  return <Shell><ErrorBoundary><Switch><Route path="/" component={Home} /><Route path="/quran/:id" component={QuranReaderPage} /><Route path="/quran" component={QuranHub} /><Route path="/adhkar/:groupId" component={DhikrReader} /><Route path="/adhkar" component={Adhkar} /><Route path="/spiritual-peace" component={SpiritualPeace} /><Route path="/tracker" component={TrackerPage} /><Route path="/articles" component={ArticlesPage} /><Route path="/hadith" component={HadithPage} /><Route path="/calendar" component={CalendarPage} /><Route path="/backup" component={BackupPage} /><Route path="/share-card" component={ShareCardPage} /><Route path="/learning" component={LearningPage} /><Route path="/recitation" component={RecitationPage} /><Route path="/daily-provision" component={DailyProvisionPage} /><Route path="/names-of-allah" component={NamesOfAllahPage} /><Route path="/ruqyah" component={RuqyahPage} /><Route path="/kids" component={KidsCornerPage} /><Route path="/zakat" component={ZakatPage} /><Route path="/binbaz" component={BinBazPage} /><Route path="/hajj/tawaf" component={TawafCounterPage} /><Route path="/hajj/bag" component={HajjBagPage} /><Route path="/hajj" component={HajjGuidePage} /><Route path="/umrah" component={UmrahGuidePage} /><Route path="/haram" component={HaramPage} /><Route path="/lodging" component={LodgingPage} /><Route path="/sunan" component={SunanTodayPage} /><Route path="/prophets" component={ProphetsStoriesPage} /><Route path="/companions" component={CompanionsPage} /><Route path="/good-deeds" component={GoodDeedsPage} /><Route path="/inheritance" component={InheritancePage} /><Route path="/tools/downloads" component={DownloadsToolPage} /><Route path="/tools/tajweed" component={TajweedToolPage} /><Route path="/tools/memorization" component={MemorizationToolPage} /><Route path="/tools/review" component={ReviewToolPage} /><Route path="/tools/reflections" component={ReflectionsToolPage} /><Route path="/dua-wall" component={DuaWallPage} /><Route path="/radio" component={RadioPage} /><Route path="/ramadan" component={RamadanPage} /><Route path="/fatwas" component={FatwaPage} /><Route path="/mosques" component={MosquesPage} /><Route path="/quiz" component={Quiz} /><Route path="/weekly-challenge" component={WeeklyChallengePage} /><Route path="/quiz-room" component={QuizRoomPage} /><Route path="/group-khatmah" component={GroupKhatmahPage} /><Route path="/ambassadors" component={Ambassadors} /><Route path="/qibla" component={Qibla} /><Route path="/tool/:slug" component={ToolScreen} /><Route path="/more" component={More} /><Route path="/settings" component={SettingsPage} /><Route path="/about" component={About} /><Route path="/admin" component={AdminPage} /><Route component={NotFound} /></Switch></ErrorBoundary></Shell>;
}

function App() {
  useEffect(() => { registerSakeenaServiceWorker(); }, []);
  return (
    <PersistQueryClientProvider
      client={queryClient}
      persistOptions={{ persister: sakeenaPersister, maxAge: 1000 * 60 * 60 * 24 * 7 }}
      onSuccess={() => queryClient.resumePausedMutations()}
    >
      <TooltipProvider><Router /><Toaster /></TooltipProvider>
    </PersistQueryClientProvider>
  );
}

export default App;
