import express, { type Express } from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// Railway/Render/etc. sit behind one reverse proxy. Without this, every client
// appears to have the proxy's IP and the rate limiters would share one bucket.
app.set("trust proxy", 1);

// ALLOWED_ORIGINS is a comma-separated list (e.g.
// "https://sakeena.app,https://www.sakeena.app"). Left unset, CORS stays
// permissive — fine for local/dev, but set this in production so the API
// only answers requests from the app's real domain(s).
const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(",").map((o) => o.trim()).filter(Boolean);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors(allowedOrigins ? { origin: allowedOrigins } : {}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// General ceiling on every /api request, per IP.
app.use(
  "/api",
  rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }),
);
// Tighter ceiling specifically on the endpoints most worth protecting from
// spam/abuse: public write-heavy ones a bot could hammer without even
// needing a device id (dua submissions, creating quiz/khatmah rooms).
app.use(
  ["/api/dua-wall", "/api/quiz-rooms", "/api/group-khatmah"],
  rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }),
);

app.use("/api", router);

export default app;
