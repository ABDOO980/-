import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface AppState {
  // Streak
  streakDays: number;
  lastActiveDate: string;
  updateStreak: () => void;

  // Quran reading progress
  currentSurah: number;
  currentPage: number;
  totalPagesRead: number;
  updateReadingProgress: (surah: number, page: number) => void;

  // Favorites
  favoriteSurahs: number[];
  toggleFavorite: (surahNumber: number) => void;

  // Tasbeeh
  tasbeehCount: number;
  incrementTasbeeh: (amount?: number) => void;
  resetTasbeeh: () => void;

  // Quiz stats
  quizScore: number;
  quizStreak: number;
  quizCorrect: number;
  quizWrong: number;
  recordQuizAnswer: (correct: boolean) => void;

  // Quick habits
  completedHabits: string[];
  toggleHabit: (habitId: string) => void;

  // Settings
  notifications: boolean;
  toggleNotifications: () => void;
  soundEnabled: boolean;
  toggleSound: () => void;
  arabicFontSize: number;
  setArabicFontSize: (size: number) => void;
}

const todayStr = () => new Date().toDateString();

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      streakDays: 1,
      lastActiveDate: '',
      updateStreak: () => {
        const last = get().lastActiveDate;
        const today = todayStr();
        if (last === today) return;
        const yesterday = new Date(Date.now() - 86400000).toDateString();
        if (last === yesterday) {
          set({ streakDays: get().streakDays + 1, lastActiveDate: today });
        } else {
          set({ streakDays: 1, lastActiveDate: today });
        }
      },

      currentSurah: 2,
      currentPage: 25,
      totalPagesRead: 25,
      updateReadingProgress: (surah, page) =>
        set({ currentSurah: surah, currentPage: page, totalPagesRead: Math.max(get().totalPagesRead, page) }),

      favoriteSurahs: [1, 36, 55, 112],
      toggleFavorite: (surahNumber) => {
        const favs = get().favoriteSurahs;
        set({
          favoriteSurahs: favs.includes(surahNumber)
            ? favs.filter((n) => n !== surahNumber)
            : [...favs, surahNumber],
        });
      },

      tasbeehCount: 0,
      incrementTasbeeh: (amount = 1) => set({ tasbeehCount: get().tasbeehCount + amount }),
      resetTasbeeh: () => set({ tasbeehCount: 0 }),

      quizScore: 0,
      quizStreak: 0,
      quizCorrect: 0,
      quizWrong: 0,
      recordQuizAnswer: (correct) => {
        const state = get();
        if (correct) {
          const newScore = state.quizScore + 100 + state.quizStreak * 10;
          set({
            quizScore: newScore,
            quizStreak: state.quizStreak + 1,
            quizCorrect: state.quizCorrect + 1,
          });
        } else {
          const penalty = Math.floor(state.quizScore * 0.4);
          set({
            quizScore: Math.max(0, state.quizScore - penalty),
            quizStreak: 0,
            quizWrong: state.quizWrong + 1,
          });
        }
      },

      completedHabits: [],
      toggleHabit: (habitId) => {
        const habits = get().completedHabits;
        set({
          completedHabits: habits.includes(habitId)
            ? habits.filter((h) => h !== habitId)
            : [...habits, habitId],
        });
      },

      notifications: true,
      toggleNotifications: () => set({ notifications: !get().notifications }),
      soundEnabled: true,
      toggleSound: () => set({ soundEnabled: !get().soundEnabled }),
      arabicFontSize: 22,
      setArabicFontSize: (size) => set({ arabicFontSize: size }),
    }),
    {
      name: 'yaqeen-sakeena-app',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
