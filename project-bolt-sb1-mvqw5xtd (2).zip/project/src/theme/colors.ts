export const Colors = {
  // Backgrounds
  bg: {
    primary: '#121212',
    secondary: '#1A1D1A',
    tertiary: '#1F2420',
    elevated: '#252B26',
    card: '#1E2420',
    cardHover: '#28302A',
  },
  // Accents
  gold: {
    50: '#FBF6E3',
    100: '#F5EBC0',
    200: '#EDD98A',
    300: '#E4C754',
    400: '#D4AF37',
    500: '#BF9B2E',
    600: '#A08424',
    700: '#7A661B',
    800: '#544812',
    900: '#2E270A',
  },
  emerald: {
    50: '#E8F5EE',
    100: '#C5E5D2',
    200: '#8FCEA8',
    300: '#5AB67E',
    400: '#2E9B5C',
    500: '#1B4D3E',
    600: '#163F32',
    700: '#112F27',
    800: '#0C201B',
    900: '#06100D',
  },
  // Semantic
  success: '#2E9B5C',
  warning: '#E4C754',
  error: '#E0524A',
  // Text
  text: {
    primary: '#F5F5F0',
    secondary: '#B5B8B0',
    tertiary: '#7A7D75',
    muted: '#5A5D55',
    onGold: '#1A1D1A',
    onEmerald: '#F5F5F0',
  },
  // Borders & lines
  border: {
    subtle: '#2A302B',
    default: '#333A34',
    strong: '#3F473E',
    gold: '#D4AF3733',
  },
  // Overlays
  overlay: {
    light: 'rgba(212,175,55,0.08)',
    dark: 'rgba(0,0,0,0.6)',
    goldGradient: 'rgba(212,175,55,0.15)',
    emeraldGradient: 'rgba(27,77,62,0.25)',
  },
};

export type ColorTheme = typeof Colors;
