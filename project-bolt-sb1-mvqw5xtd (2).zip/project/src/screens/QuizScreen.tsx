import { useState, useMemo } from 'react';
import {
  View, StyleSheet, Text, Pressable, ScrollView, FlatList,
} from 'react-native';
import {
  Swords, Trophy, Zap, X, Check, AlertCircle, Link as LinkIcon, Copy,
} from 'lucide-react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';
import { quizQuestions, QuizQuestion } from '@/src/data/quiz';
import { weeklyChampions } from '@/src/data/content';
import { useAppStore } from '@/src/store/useAppStore';
import { ProgressBar } from '@/src/components/ui';

type Mode = 'menu' | 'solo' | 'duel' | 'friday';

export function QuizScreen() {
  const [mode, setMode] = useState<Mode>('menu');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [questions] = useState<QuizQuestion[]>(() => {
    const shuffled = [...quizQuestions].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, 10);
  });

  const { quizScore, quizStreak, quizCorrect, quizWrong, recordQuizAnswer } = useAppStore();

  const currentQ = questions[currentIndex];
  const isLastQ = currentIndex === questions.length - 1;

  const handleAnswer = (index: number) => {
    if (showResult) return;
    setSelectedAnswer(index);
    setShowResult(true);
    recordQuizAnswer(index === currentQ.correctIndex);
  };

  const handleNext = () => {
    if (isLastQ) {
      setMode('menu');
      setCurrentIndex(0);
      setSelectedAnswer(null);
      setShowResult(false);
      return;
    }
    setCurrentIndex(currentIndex + 1);
    setSelectedAnswer(null);
    setShowResult(false);
  };

  const accuracy = quizCorrect + quizWrong > 0 ? Math.round((quizCorrect / (quizCorrect + quizWrong)) * 100) : 0;

  if (mode === 'solo' || mode === 'duel') {
    return (
      <View style={styles.container}>
        {/* Quiz Header */}
        <View style={styles.quizHeader}>
          <Pressable onPress={() => setMode('menu')} style={styles.closeBtn}>
            <X size={22} color={Colors.text.secondary} strokeWidth={2} />
          </Pressable>
          <View style={styles.quizProgressWrap}>
            <Text style={styles.quizProgressText}>{currentIndex + 1} / {questions.length}</Text>
            <View style={styles.quizProgressBar}>
              <ProgressBar progress={(currentIndex + 1) / questions.length} height={4} />
            </View>
          </View>
          <View style={styles.streakBadge}>
            <Zap size={16} color={Colors.gold[400]} strokeWidth={2} />
            <Text style={styles.streakText}>{quizStreak}</Text>
          </View>
        </View>

        {/* Score & Penalty */}
        <View style={styles.scoreRow}>
          <View style={styles.scoreBox}>
            <Text style={styles.scoreLabel}>النقاط</Text>
            <Text style={styles.scoreValue}>{quizScore}</Text>
          </View>
          <View style={styles.penaltyBox}>
            <AlertCircle size={14} color={Colors.error} strokeWidth={2} />
            <Text style={styles.penaltyText}>خصم 40% على الغلط</Text>
          </View>
        </View>

        {/* Question */}
        <ScrollView contentContainerStyle={styles.quizBody} showsVerticalScrollIndicator={false}>
          <View style={styles.questionCard}>
            <View style={styles.categoryTag}>
              <Text style={styles.categoryTagText}>{currentQ.category}</Text>
            </View>
            <Text style={styles.questionText}>{currentQ.question}</Text>
          </View>

          {/* Options */}
          <View style={styles.optionsWrap}>
            {currentQ.options.map((option, i) => {
              const isSelected = selectedAnswer === i;
              const isCorrect = i === currentQ.correctIndex;
              const showCorrect = showResult && isCorrect;
              const showWrong = showResult && isSelected && !isCorrect;

              return (
                <Pressable
                  key={i}
                  onPress={() => handleAnswer(i)}
                  disabled={showResult}
                  style={[
                    styles.optionBtn,
                    showCorrect && styles.optionCorrect,
                    showWrong && styles.optionWrong,
                    !showResult && isSelected && styles.optionSelected,
                  ]}
                >
                  <View style={styles.optionLetter}>
                    <Text style={styles.optionLetterText}>{['أ', 'ب', 'ج', 'د'][i]}</Text>
                  </View>
                  <Text style={styles.optionText}>{option}</Text>
                  {showCorrect && <Check size={20} color={Colors.success} strokeWidth={3} />}
                  {showWrong && <X size={20} color={Colors.error} strokeWidth={3} />}
                </Pressable>
              );
            })}
          </View>

          {/* Explanation */}
          {showResult && currentQ.explanation && (
            <View style={styles.explanationCard}>
              <Text style={styles.explanationTitle}>التفسير</Text>
              <Text style={styles.explanationText}>{currentQ.explanation}</Text>
            </View>
          )}

          {showResult && (
            <Pressable style={styles.nextBtn} onPress={handleNext}>
              <Text style={styles.nextBtnText}>
                {isLastQ ? 'إنهاء' : 'السؤال التالي'}
              </Text>
            </Pressable>
          )}
        </ScrollView>
      </View>
    );
  }

  // Menu mode
  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.screenTitle}>مسابقة يقين</Text>
        </View>

        {/* Score & Streak Tracker */}
        <View style={styles.statsCard}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{quizScore}</Text>
            <Text style={styles.statLabel}>النقاط</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{quizStreak}</Text>
            <Text style={styles.statLabel}>سلسلة</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: Colors.success }]}>{accuracy}%</Text>
            <Text style={styles.statLabel}>الدقة</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: Colors.error }]}>{quizWrong}</Text>
            <Text style={styles.statLabel}>أخطاء</Text>
          </View>
        </View>

        <View style={styles.penaltyInfo}>
          <AlertCircle size={14} color={Colors.error} strokeWidth={2} />
          <Text style={styles.penaltyInfoText}>خصم 40% من النقاط على كل إجابة خاطئة</Text>
        </View>

        {/* Duel Mode */}
        <Pressable style={styles.modeCard} onPress={() => setMode('duel')}>
          <View style={styles.modeIconWrap}>
            <Swords size={28} color={Colors.gold[400]} strokeWidth={2} />
          </View>
          <View style={styles.modeInfo}>
            <Text style={styles.modeTitle}>الغريم</Text>
            <Text style={styles.modeDesc}>تحدّى صديقك في معركة 1 ضد 1</Text>
          </View>
          <Text style={styles.modeArrow}>‹</Text>
        </Pressable>

        {/* Solo Mode */}
        <Pressable style={styles.modeCard} onPress={() => setMode('solo')}>
          <View style={styles.modeIconWrap}>
            <Zap size={28} color={Colors.gold[400]} strokeWidth={2} />
          </View>
          <View style={styles.modeInfo}>
            <Text style={styles.modeTitle}>تحدّي نفسك</Text>
            <Text style={styles.modeDesc}>10 أسئلة متنوعة في العلوم الإسلامية</Text>
          </View>
          <Text style={styles.modeArrow}>‹</Text>
        </Pressable>

        {/* Invite Link Section */}
        <View style={styles.inviteCard}>
          <View style={styles.inviteHeader}>
            <LinkIcon size={18} color={Colors.gold[400]} strokeWidth={2} />
            <Text style={styles.inviteTitle}>رمز التحدي</Text>
          </View>
          <View style={styles.codeRow}>
            <Text style={styles.codeText}>YAQEEN-7281</Text>
            <Pressable style={styles.copyBtn}>
              <Copy size={16} color={Colors.text.onGold} strokeWidth={2} />
              <Text style={styles.copyBtnText}>نسخ</Text>
            </Pressable>
          </View>
          <Text style={styles.inviteDesc}>شارك هذا الرمز مع صديق لبدء تحدي مباشر</Text>
        </View>

        {/* Friday Championship */}
        <View style={styles.fridayCard}>
          <View style={styles.fridayHeader}>
            <View style={styles.fridayIconWrap}>
              <Trophy size={24} color={Colors.gold[400]} strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.fridayTitle}>بطولة الجمعة</Text>
              <Text style={styles.fridayDesc}>تحدّي أسبوعي موحّد لكل المتسابقين</Text>
            </View>
          </View>

          <View style={styles.leaderboardTitleWrap}>
            <Text style={styles.leaderboardTitle}>لوحة متصدري بطولة الجمعة</Text>
          </View>

          {weeklyChampions.map((champ) => (
            <View key={champ.rank} style={[
              styles.leaderRow,
              champ.rank === 1 && styles.leaderRowTop,
            ]}>
              <View style={[
                styles.rankBadge,
                champ.rank === 1 && styles.rankBadgeGold,
                champ.rank === 2 && styles.rankBadgeSilver,
                champ.rank === 3 && styles.rankBadgeBronze,
              ]}>
                <Text style={styles.rankText}>{champ.rank}</Text>
              </View>
              <Text style={styles.leaderEmoji}>
                {champ.rank === 1 ? '👑' : champ.rank === 2 ? '🥈' : champ.rank === 3 ? '🥉' : '⭐'}
              </Text>
              <Text style={styles.leaderName}>{champ.name}</Text>
              <View style={styles.leagueBadge}>
                <Text style={styles.leagueText}>{champ.league}</Text>
              </View>
              <Text style={styles.leaderScore}>{champ.score.toLocaleString('ar-EG')}</Text>
            </View>
          ))}
        </View>

        <View style={{ height: Spacing.xxl }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg.primary },
  content: { padding: Spacing.md, paddingTop: Spacing.xl + 8, gap: Spacing.md },
  header: { marginBottom: Spacing.xs },
  screenTitle: {
    fontSize: Typography.sizes.xxxl,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  // Stats
  statsCard: {
    flexDirection: 'row',
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.gold,
  },
  statItem: { flex: 1, alignItems: 'center' },
  statValue: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[400],
  },
  statLabel: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  statDivider: {
    width: 1,
    backgroundColor: Colors.border.subtle,
  },
  penaltyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.sm,
  },
  penaltyInfoText: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
  },
  // Mode cards
  modeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
    gap: Spacing.md,
  },
  modeIconWrap: {
    width: 52,
    height: 52,
    borderRadius: Radius.md,
    backgroundColor: Colors.overlay.goldGradient,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modeInfo: { flex: 1 },
  modeTitle: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  modeDesc: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  modeArrow: {
    fontSize: 24,
    color: Colors.text.muted,
  },
  // Invite
  inviteCard: {
    backgroundColor: Colors.emerald[700],
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.emerald[600],
  },
  inviteHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  inviteTitle: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[200],
  },
  codeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.sm,
  },
  codeText: {
    fontSize: Typography.sizes.xl,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[300],
    letterSpacing: 2,
  },
  copyBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.gold[400],
    borderRadius: Radius.sm,
    paddingVertical: Spacing.xs,
    paddingHorizontal: Spacing.sm,
  },
  copyBtnText: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.onGold,
  },
  inviteDesc: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
  },
  // Friday Championship
  fridayCard: {
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.gold,
  },
  fridayHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  fridayIconWrap: {
    width: 48,
    height: 48,
    borderRadius: Radius.md,
    backgroundColor: Colors.overlay.goldGradient,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fridayTitle: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[400],
  },
  fridayDesc: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  leaderboardTitleWrap: {
    paddingBottom: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border.subtle,
    marginBottom: Spacing.sm,
  },
  leaderboardTitle: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.secondary,
  },
  leaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.sm,
  },
  leaderRowTop: {},
  rankBadge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.bg.tertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankBadgeGold: { backgroundColor: Colors.gold[400] },
  rankBadgeSilver: { backgroundColor: '#C0C0C0' },
  rankBadgeBronze: { backgroundColor: '#CD7F32' },
  rankText: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Tajawal-Bold',
    color: Colors.text.primary,
  },
  leaderEmoji: { fontSize: 18 },
  leaderName: {
    flex: 1,
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.primary,
  },
  leagueBadge: {
    backgroundColor: Colors.emerald[800],
    borderRadius: Radius.xs,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  leagueText: {
    fontSize: 10,
    fontFamily: 'Cairo-Regular',
    color: Colors.gold[300],
  },
  leaderScore: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[300],
  },
  // Quiz mode
  quizHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.xxl,
    paddingBottom: Spacing.md,
    gap: Spacing.md,
  },
  closeBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.bg.tertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quizProgressWrap: { flex: 1 },
  quizProgressText: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginBottom: 4,
  },
  quizProgressBar: {},
  streakBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.overlay.goldGradient,
    borderRadius: Radius.pill,
    paddingVertical: 6,
    paddingHorizontal: Spacing.sm,
  },
  streakText: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[400],
  },
  scoreRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.md,
  },
  scoreBox: {},
  scoreLabel: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
  },
  scoreValue: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[400],
  },
  penaltyBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(224,82,74,0.1)',
    borderRadius: Radius.pill,
    paddingVertical: 4,
    paddingHorizontal: Spacing.sm,
  },
  penaltyText: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.error,
  },
  quizBody: { padding: Spacing.md, paddingBottom: Spacing.xxl },
  questionCard: {
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.xl,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
    marginBottom: Spacing.lg,
  },
  categoryTag: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.emerald[800],
    borderRadius: Radius.pill,
    paddingVertical: 4,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.md,
  },
  categoryTagText: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.gold[300],
  },
  questionText: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
    lineHeight: 1.5,
  },
  optionsWrap: { gap: Spacing.sm },
  optionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.border.subtle,
  },
  optionSelected: {
    borderColor: Colors.gold[400],
    backgroundColor: Colors.overlay.goldGradient,
  },
  optionCorrect: {
    borderColor: Colors.success,
    backgroundColor: 'rgba(46,155,92,0.1)',
  },
  optionWrong: {
    borderColor: Colors.error,
    backgroundColor: 'rgba(224,82,74,0.1)',
  },
  optionLetter: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.bg.tertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  optionLetterText: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.secondary,
  },
  optionText: {
    flex: 1,
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.primary,
  },
  explanationCard: {
    backgroundColor: Colors.emerald[800],
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.emerald[600],
    marginTop: Spacing.md,
  },
  explanationTitle: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[200],
    marginBottom: Spacing.sm,
  },
  explanationText: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
    lineHeight: 1.6,
  },
  nextBtn: {
    backgroundColor: Colors.gold[400],
    borderRadius: Radius.lg,
    paddingVertical: Spacing.md,
    alignItems: 'center',
    marginTop: Spacing.lg,
  },
  nextBtnText: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.onGold,
  },
});
