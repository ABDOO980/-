import { useState, useMemo } from 'react';
import {
  View, StyleSheet, Text, ScrollView, Pressable, FlatList, Modal,
} from 'react-native';
import {
  Sunrise, Sunset, Moon, Sun, HandsPraying, Heart, X, RotateCcw,
} from 'lucide-react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';
import { adhkarCategories, AdhkarCategory, DhikrItem } from '@/src/data/adhkar';
import { situationalPrayers } from '@/src/data/quiz';
import { SearchBar } from '@/src/components/ui';

const iconMap: Record<string, any> = {
  sunrise: Sunrise,
  sunset: Sunset,
  moon: Moon,
  sun: Sun,
  'hands-praying': HandsPraying,
  heart: Heart,
};

export function AdhkarScreen() {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<AdhkarCategory | null>(null);
  const [dhikrCounts, setDhikrCounts] = useState<Record<string, number>>({});

  const filteredCategories = useMemo(() => {
    if (!search.trim()) return adhkarCategories;
    return adhkarCategories.map((cat) => ({
      ...cat,
      items: cat.items.filter((item) => item.text.includes(search) || (item.virtue?.includes(search) ?? false)),
    })).filter((cat) => cat.items.length > 0);
  }, [search]);

  const handleCount = (dhikrId: string, maxCount: number) => {
    const current = dhikrCounts[dhikrId] || 0;
    if (current < maxCount) {
      setDhikrCounts({ ...dhikrCounts, [dhikrId]: current + 1 });
    } else {
      setDhikrCounts({ ...dhikrCounts, [dhikrId]: 0 });
    }
  };

  const renderDhikrItem = (item: DhikrItem) => {
    const count = dhikrCounts[item.id] || 0;
    const completed = count >= item.count;

    return (
      <View key={item.id} style={[styles.dhikrItem, completed && styles.dhikrItemDone]}>
        <Text style={styles.dhikrText}>{item.text}</Text>
        {item.virtue && <Text style={styles.dhikrVirtue}>✦ {item.virtue}</Text>}
        {item.reference && <Text style={styles.dhikrRef}>{item.reference}</Text>}
        <View style={styles.dhikrCounterRow}>
          <Pressable
            style={[styles.counterBtn, completed && styles.counterBtnDone]}
            onPress={() => handleCount(item.id, item.count)}
          >
            <Text style={[styles.counterText, completed && styles.counterTextDone]}>
              {completed ? 'تم ✓' : `${count} / ${item.count}`}
            </Text>
          </Pressable>
          {count > 0 && !completed && (
            <Pressable
              onPress={() => setDhikrCounts({ ...dhikrCounts, [item.id]: 0 })}
              hitSlop={8}
            >
              <RotateCcw size={16} color={Colors.text.muted} strokeWidth={2} />
            </Pressable>
          )}
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.screenTitle}>الأذكار</Text>
        <Text style={styles.screenSubtitle}>حصن المسلم</Text>
      </View>

      <View style={styles.searchWrap}>
        <SearchBar
          value={search}
          onChangeText={setSearch}
          placeholder="ابحث في الأذكار..."
        />
      </View>

      {/* Situational Prayers Banner */}
      <View style={styles.situationalBanner}>
        <View style={styles.situationalHeader}>
          <HandsPraying size={24} color={Colors.gold[400]} strokeWidth={2} />
          <View>
            <Text style={styles.situationalTitle}>أدعية المواقف</Text>
            <Text style={styles.situationalDesc}>أدعية لكل موقف وحالة</Text>
          </View>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.situationalList}>
          {situationalPrayers.map((sp) => (
            <View key={sp.id} style={styles.situationalChip}>
              <Text style={styles.situationalChipTitle}>{sp.title}</Text>
            </View>
          ))}
        </ScrollView>
      </View>

      <FlatList
        data={filteredCategories}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          const Icon = iconMap[item.icon] || Heart;
          const totalCount = item.items.length;
          const doneCount = item.items.filter((i) => (dhikrCounts[i.id] || 0) >= i.count).length;

          return (
            <Pressable
              style={({ pressed }) => [styles.categoryCard, pressed && styles.pressed]}
              onPress={() => setSelectedCategory(item)}
            >
              <View style={styles.categoryIconWrap}>
                <Icon size={24} color={Colors.gold[400]} strokeWidth={2} />
              </View>
              <View style={styles.categoryInfo}>
                <Text style={styles.categoryTitle}>{item.title}</Text>
                <Text style={styles.categorySubtitle}>{item.subtitle}</Text>
                <View style={styles.categoryMeta}>
                  <Text style={styles.categoryCount}>{totalCount} ذكر</Text>
                  {doneCount > 0 && (
                    <View style={styles.doneBadge}>
                      <Text style={styles.doneBadgeText}>{doneCount} مكتمل</Text>
                    </View>
                  )}
                </View>
              </View>
              <View style={styles.categoryArrow}>
                <Text style={styles.arrowText}>‹</Text>
              </View>
            </Pressable>
          );
        }}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={{ height: Spacing.sm }} />}
      />

      {/* Category Detail Modal */}
      <Modal
        visible={selectedCategory !== null}
        animationType="slide"
        onRequestClose={() => setSelectedCategory(null)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Pressable onPress={() => setSelectedCategory(null)} style={styles.closeBtn}>
              <X size={24} color={Colors.text.secondary} strokeWidth={2} />
            </Pressable>
            <View style={styles.modalTitleWrap}>
              <Text style={styles.modalTitle}>{selectedCategory?.title}</Text>
              <Text style={styles.modalSubtitle}>{selectedCategory?.subtitle}</Text>
            </View>
          </View>
          <ScrollView
            style={styles.modalBody}
            contentContainerStyle={{ paddingBottom: Spacing.xxl }}
            showsVerticalScrollIndicator={false}
          >
            {selectedCategory?.items.map((item) => renderDhikrItem(item))}
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg.primary },
  header: {
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.xl + 8,
    paddingBottom: Spacing.sm,
  },
  screenTitle: {
    fontSize: Typography.sizes.xxxl,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  screenSubtitle: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.gold[400],
    marginTop: 2,
  },
  searchWrap: {
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
  },
  situationalBanner: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border.gold,
  },
  situationalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    marginBottom: Spacing.md,
  },
  situationalTitle: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[400],
  },
  situationalDesc: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  situationalList: {},
  situationalChip: {
    backgroundColor: Colors.bg.tertiary,
    borderRadius: Radius.pill,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    marginRight: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.border.default,
  },
  situationalChipTitle: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
  },
  list: {
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.xxl,
  },
  categoryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
    gap: Spacing.md,
  },
  pressed: { opacity: 0.85, transform: [{ scale: 0.98 }] },
  categoryIconWrap: {
    width: 48,
    height: 48,
    borderRadius: Radius.md,
    backgroundColor: Colors.overlay.goldGradient,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryInfo: { flex: 1 },
  categoryTitle: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  categorySubtitle: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  categoryMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginTop: Spacing.sm,
  },
  categoryCount: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.muted,
  },
  doneBadge: {
    backgroundColor: Colors.emerald[500],
    borderRadius: Radius.xs,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  doneBadgeText: {
    fontSize: 10,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.onEmerald,
  },
  categoryArrow: {},
  arrowText: {
    fontSize: 24,
    color: Colors.text.muted,
  },
  // Modal
  modalContainer: {
    flex: 1,
    backgroundColor: Colors.bg.primary,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.xxl,
    paddingBottom: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border.subtle,
    gap: Spacing.md,
  },
  closeBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.bg.tertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalTitleWrap: { flex: 1 },
  modalTitle: {
    fontSize: Typography.sizes.xl,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  modalSubtitle: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  modalBody: {
    padding: Spacing.md,
  },
  dhikrItem: {
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
  },
  dhikrItemDone: {
    borderColor: Colors.emerald[400],
    backgroundColor: Colors.emerald[800],
  },
  dhikrText: {
    fontSize: Typography.sizes.xl,
    fontFamily: 'Amiri-Regular',
    color: Colors.text.primary,
    lineHeight: 1.8,
    textAlign: 'center',
  },
  dhikrVirtue: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.gold[300],
    marginTop: Spacing.sm,
    textAlign: 'center',
  },
  dhikrRef: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: Spacing.xs,
    textAlign: 'center',
  },
  dhikrCounterRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.md,
    marginTop: Spacing.md,
  },
  counterBtn: {
    backgroundColor: Colors.gold[400],
    borderRadius: Radius.pill,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.xl,
  },
  counterBtnDone: {
    backgroundColor: Colors.emerald[500],
  },
  counterText: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.onGold,
  },
  counterTextDone: {
    color: Colors.text.onEmerald,
  },
});
