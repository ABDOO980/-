import { useState, useMemo } from 'react';
import { View, StyleSheet, Text, ScrollView, Pressable } from 'react-native';
import {
  BookOpen, Download, Search, Heart, BookText, GraduationCap,
  Brain, Complete, RefreshCw, Mic, ScrollText, FileText,
  Lightbulb, HandHeart, Users, Plane, Crown, Gift,
} from 'lucide-react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';
import { SearchBar } from '@/src/components/ui';
import { weeklyChampions } from '@/src/data/content';

interface ToolItem {
  id: string;
  label: string;
  icon: any;
  color?: string;
}

interface ToolCategory {
  id: string;
  title: string;
  items: ToolItem[];
}

const quranTools: ToolItem[] = [
  { id: 'q1', label: 'المصحف', icon: BookOpen },
  { id: 'q2', label: 'التحميلات', icon: Download },
  { id: 'q3', label: 'بحث الآيات', icon: Search },
  { id: 'q4', label: 'المفضلة', icon: Heart },
  { id: 'q5', label: 'تفسير وتدبر', icon: BookText },
  { id: 'q6', label: 'دروس التجويد', icon: GraduationCap },
];

const memorizationTools: ToolItem[] = [
  { id: 'm1', label: 'المحفظ', icon: Brain },
  { id: 'm2', label: 'أكمل الآية', icon: Complete },
  { id: 'm3', label: 'مراجعة الحفظ', icon: RefreshCw },
  { id: 'm4', label: 'تسميع (رتل بصوتك)', icon: Mic },
  { id: 'm5', label: 'الورد والختمة', icon: ScrollText },
  { id: 'm6', label: 'فهرس المواضيع', icon: FileText },
  { id: 'm7', label: 'تدبراتي', icon: Lightbulb },
  { id: 'm8', label: 'عباداتي', icon: HandHeart },
];

const mainCategories: ToolItem[] = [
  { id: 'c1', label: 'عبادتك اليوم', icon: HandHeart },
  { id: 'c2', label: 'الدعاء والذكر', icon: Heart },
  { id: 'c3', label: 'القرآن الكريم', icon: BookOpen },
  { id: 'c4', label: 'الفقه والمواسم', icon: BookText },
  { id: 'c5', label: 'العلم والمعرفة', icon: GraduationCap },
  { id: 'c6', label: 'حفظ ومتابعة', icon: Brain },
  { id: 'c7', label: 'العائلة والمشاركة', icon: Users },
  { id: 'c8', label: 'الحج والعمرة', icon: Plane },
];

export function MoreScreen() {
  const [search, setSearch] = useState('');

  const filteredQuranTools = useMemo(() => {
    if (!search.trim()) return quranTools;
    return quranTools.filter((t) => t.label.includes(search));
  }, [search]);

  const filteredMemTools = useMemo(() => {
    if (!search.trim()) return memorizationTools;
    return memorizationTools.filter((t) => t.label.includes(search));
  }, [search]);

  const renderToolGrid = (items: ToolItem[], columns: number = 4) => (
    <View style={styles.grid}>
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <Pressable
            key={item.id}
            style={({ pressed }) => [styles.toolItem, pressed && styles.pressed]}
          >
            <View style={styles.toolIconWrap}>
              <Icon size={22} color={Colors.gold[400]} strokeWidth={2} />
            </View>
            <Text style={styles.toolLabel}>{item.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.screenTitle}>المزيد والأدوات</Text>
      </View>

      <SearchBar
        value={search}
        onChangeText={setSearch}
        placeholder="ابحث في الأدوات..."
      />

      {/* Quran Tools */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>أدوات القرآن</Text>
        {renderToolGrid(filteredQuranTools)}
      </View>

      {/* Memorization Tools */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>الحفظ والمتابعة</Text>
        {renderToolGrid(filteredMemTools)}
      </View>

      {/* Main Categories */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>التصنيفات الرئيسية</Text>
        <View style={styles.categoryGrid}>
          {mainCategories.map((item) => {
            const Icon = item.icon;
            return (
              <Pressable
                key={item.id}
                style={({ pressed }) => [styles.categoryCard, pressed && styles.pressed]}
              >
                <View style={styles.categoryIconWrap}>
                  <Icon size={26} color={Colors.gold[400]} strokeWidth={2} />
                </View>
                <Text style={styles.categoryLabel}>{item.label}</Text>
                <Text style={styles.categoryArrow}>‹</Text>
              </Pressable>
            );
          })}
        </View>
      </View>

      {/* Community Section */}
      <View style={styles.section}>
        <View style={styles.communityHeader}>
          <View style={styles.communityIconWrap}>
            <Users size={22} color={Colors.gold[400]} strokeWidth={2} />
          </View>
          <View>
            <Text style={styles.communityTitle}>مجتمع يقين</Text>
            <Text style={styles.communityDesc}>أبطال الأسبوع والدوريات</Text>
          </View>
        </View>

        {/* Weekly Champions */}
        <View style={styles.championsCard}>
          <View style={styles.championsHeader}>
            <Crown size={18} color={Colors.gold[400]} strokeWidth={2} />
            <Text style={styles.championsTitle}>أبطال الأسبوع</Text>
          </View>
          {weeklyChampions.slice(0, 5).map((champ) => (
            <View key={champ.rank} style={styles.champRow}>
              <View style={[
                styles.champRankBadge,
                champ.rank === 1 && styles.champRankGold,
                champ.rank === 2 && styles.champRankSilver,
                champ.rank === 3 && styles.champRankBronze,
              ]}>
                <Text style={styles.champRankText}>{champ.rank}</Text>
              </View>
              <Text style={styles.champEmoji}>
                {champ.rank === 1 ? '👑' : champ.rank === 2 ? '🥈' : champ.rank === 3 ? '🥉' : '⭐'}
              </Text>
              <Text style={styles.champName}>{champ.name}</Text>
              <View style={styles.leagueBadge}>
                <Text style={styles.leagueText}>{champ.league}</Text>
              </View>
              <Text style={styles.champScore}>{champ.score.toLocaleString('ar-EG')}</Text>
            </View>
          ))}
        </View>

        {/* Leagues */}
        <View style={styles.leaguesRow}>
          {['الذهبية', 'الفضية', 'البرونزية', 'النحاسية'].map((league, i) => (
            <View
              key={league}
              style={[
                styles.leagueChip,
                i === 0 && styles.leagueChipGold,
                i === 1 && styles.leagueChipSilver,
                i === 2 && styles.leagueChipBronze,
                i === 3 && styles.leagueChipCopper,
              ]}
            >
              <Text style={styles.leagueChipText}>{league}</Text>
            </View>
          ))}
        </View>

        {/* Referral Progress */}
        <View style={styles.referralCard}>
          <View style={styles.referralHeader}>
            <Gift size={18} color={Colors.gold[400]} strokeWidth={2} />
            <Text style={styles.referralTitle}>تقدّم الدعوات</Text>
          </View>
          <View style={styles.referralProgress}>
            <View style={styles.referralBarBg}>
              <View style={styles.referralBarFill} />
            </View>
            <Text style={styles.referralStats}>7 / 10 دعوات</Text>
          </View>
          <Text style={styles.referralReward}>ادعُ 3 أصدقاء آخرين واحصل على شارة سفير يقين</Text>
        </View>
      </View>

      <View style={{ height: Spacing.xxl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg.primary },
  content: { padding: Spacing.md, paddingTop: Spacing.xl + 8, gap: Spacing.lg },
  header: { marginBottom: Spacing.xs },
  screenTitle: {
    fontSize: Typography.sizes.xxxl,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  section: {},
  sectionTitle: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[400],
    marginBottom: Spacing.md,
  },
  // Tool grid
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  toolItem: {
    width: '23%',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  pressed: { opacity: 0.7, transform: [{ scale: 0.95 }] },
  toolIconWrap: {
    width: 56,
    height: 56,
    borderRadius: Radius.lg,
    backgroundColor: Colors.bg.card,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.border.subtle,
  },
  toolLabel: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
    textAlign: 'center',
    lineHeight: 1.3,
  },
  // Category cards
  categoryGrid: {
    gap: Spacing.sm,
  },
  categoryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
    gap: Spacing.md,
  },
  categoryIconWrap: {
    width: 48,
    height: 48,
    borderRadius: Radius.md,
    backgroundColor: Colors.overlay.goldGradient,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryLabel: {
    flex: 1,
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  categoryArrow: {
    fontSize: 24,
    color: Colors.text.muted,
  },
  // Community
  communityHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    marginBottom: Spacing.md,
  },
  communityIconWrap: {
    width: 44,
    height: 44,
    borderRadius: Radius.md,
    backgroundColor: Colors.overlay.goldGradient,
    alignItems: 'center',
    justifyContent: 'center',
  },
  communityTitle: {
    fontSize: Typography.sizes.xl,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  communityDesc: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  championsCard: {
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.gold,
    marginBottom: Spacing.md,
  },
  championsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
    paddingBottom: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border.subtle,
  },
  championsTitle: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[400],
  },
  champRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.sm,
  },
  champRankBadge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.bg.tertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  champRankGold: { backgroundColor: Colors.gold[400] },
  champRankSilver: { backgroundColor: '#C0C0C0' },
  champRankBronze: { backgroundColor: '#CD7F32' },
  champRankText: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Tajawal-Bold',
    color: Colors.text.primary,
  },
  champEmoji: { fontSize: 18 },
  champName: {
    flex: 1,
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.primary,
  },
  leagueBadge: {
    backgroundColor: Colors.emerald[800],
    borderRadius: Radius.xs,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  leagueText: {
    fontSize: 10,
    fontFamily: 'Cairo-Regular',
    color: Colors.gold[300],
  },
  champScore: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[300],
  },
  // Leagues
  leaguesRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
    flexWrap: 'wrap',
  },
  leagueChip: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: Radius.pill,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderWidth: 1,
  },
  leagueChipGold: {
    backgroundColor: 'rgba(212,175,55,0.15)',
    borderColor: Colors.gold[400],
  },
  leagueChipSilver: {
    backgroundColor: 'rgba(192,192,192,0.1)',
    borderColor: '#C0C0C0',
  },
  leagueChipBronze: {
    backgroundColor: 'rgba(205,127,50,0.1)',
    borderColor: '#CD7F32',
  },
  leagueChipCopper: {
    backgroundColor: 'rgba(184,115,51,0.1)',
    borderColor: '#B87333',
  },
  leagueChipText: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.secondary,
  },
  // Referral
  referralCard: {
    backgroundColor: Colors.emerald[700],
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.emerald[600],
  },
  referralHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  referralTitle: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[200],
  },
  referralProgress: {
    marginBottom: Spacing.sm,
  },
  referralBarBg: {
    height: 8,
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: Spacing.xs,
  },
  referralBarFill: {
    height: '100%',
    width: '70%',
    backgroundColor: Colors.gold[400],
    borderRadius: 4,
  },
  referralStats: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[300],
    textAlign: 'left',
  },
  referralReward: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
  },
});
