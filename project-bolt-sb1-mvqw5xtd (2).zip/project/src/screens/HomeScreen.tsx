import { useEffect } from 'react';
import { View, StyleSheet, Text, Pressable, ScrollView } from 'react-native';
import { Bell, Settings, BarChart3, Flame } from 'lucide-react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';
import { useAppStore } from '@/src/store/useAppStore';
import { CountdownTimer, ProgressBar } from '@/src/components/ui';
import { SearchBar as UISearchBar } from '@/src/components/ui';
import { getHijriDate, getGregorianDate, getPrayerTimes, getNextPrayer } from '@/src/data/prayers';
import { tasbeehLeaderboard } from '@/src/data/content';
import { surahs } from '@/src/data/surahs';
import { islamicQuotes } from '@/src/data/content';

const quickHabits = [
  { id: 'h1', label: 'صفحة من القرآن', icon: '📖' },
  { id: 'h2', label: 'أذكار الصباح', icon: '🌅' },
  { id: 'h3', label: 'أذكار المساء', icon: '🌙' },
  { id: 'h4', label: 'صدقة', icon: '🤲' },
];

const prayerIcons: Record<string, string> = {
  fajr: '🌅', sunrise: '☀️', dhuhr: '🌞', asr: '⛅', maghrib: '🌇', isha: '🌙',
};

export function HomeScreen() {
  const {
    streakDays, updateStreak, tasbeehCount, incrementTasbeeh, completedHabits, toggleHabit,
    currentSurah, currentPage, totalPagesRead, toggleFavorite,
  } = useAppStore();

  useEffect(() => {
    updateStreak();
  }, []);

  const hijriDate = getHijriDate();
  const gregorianDate = getGregorianDate();
  const prayerTimes = getPrayerTimes();
  const nextPrayer = getNextPrayer();
  const surah = surahs.find((s) => s.number === currentSurah);
  const quote = islamicQuotes[new Date().getDate() % islamicQuotes.length];
  const tasbeehTarget = 1000000;
  const tasbeehProgress = (tasbeehCount + 487200) / tasbeehTarget;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.greeting}>
          <Text style={styles.salam}>السلام عليكم ورحمة الله</Text>
          <Text style={styles.dateText}>{gregorianDate}</Text>
        </View>
        <View style={styles.headerActions}>
          <Pressable style={styles.headerIcon}>
            <BarChart3 size={20} color={Colors.gold[400]} strokeWidth={2} />
          </Pressable>
          <Pressable style={styles.headerIcon}>
            <Bell size={20} color={Colors.text.secondary} strokeWidth={2} />
          </Pressable>
          <Pressable style={styles.headerIcon}>
            <Settings size={20} color={Colors.text.secondary} strokeWidth={2} />
          </Pressable>
        </View>
      </View>

      {/* Streak Widget */}
      <View style={styles.streakCard}>
        <View style={styles.streakLeft}>
          <View style={styles.flameWrap}>
            <Flame size={28} color={Colors.gold[400]} strokeWidth={2} />
          </View>
          <View>
            <Text style={styles.streakTitle}>شعلتك النهاردة</Text>
            <Text style={styles.streakCount}>{streakDays} يوم متتالي 🔥</Text>
          </View>
        </View>
        <CountdownTimer
          seconds={Math.max(0, 86400 - (new Date().getHours() * 3600 + new Date().getMinutes() * 60))}
          label="متبقي على اليوم"
        />
      </View>

      {/* Search */}
      <UISearchBar
        value=""
        onChangeText={() => {}}
        placeholder="ابحث في القرآن، السور، والأذكار..."
      />

      {/* Prayer Times Card */}
      <View style={styles.prayerCard}>
        <View style={styles.prayerHeader}>
          <View>
            <Text style={styles.hijriDate}>{hijriDate}</Text>
            <Text style={styles.gregDate}>{gregorianDate}</Text>
          </View>
          <View style={styles.nextPrayerWrap}>
            <Text style={styles.nextPrayerLabel}>الصلاة القادمة</Text>
            <Text style={styles.nextPrayerName}>{nextPrayer.name}</Text>
            <Text style={styles.nextPrayerTime}>{nextPrayer.time}</Text>
            <CountdownTimer seconds={nextPrayer.remainingSeconds} label="متبقي" />
          </View>
        </View>
        <View style={styles.prayerTimesRow}>
          {prayerTimes.map((p) => (
            <View key={p.key} style={[
              styles.prayerTimeChip,
              p.name === nextPrayer.name && styles.prayerTimeChipActive,
            ]}>
              <Text style={styles.prayerEmoji}>{prayerIcons[p.key]}</Text>
              <Text style={[
                styles.prayerName,
                p.name === nextPrayer.name && styles.prayerNameActive,
              ]}>{p.name}</Text>
              <Text style={[
                styles.prayerTime,
                p.name === nextPrayer.name && styles.prayerTimeActive,
              ]}>{p.time}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Hidden Intercession Card */}
      <View style={styles.intercessionCard}>
        <Text style={styles.intercessionEmoji}>🤲</Text>
        <View style={styles.intercessionBody}>
          <Text style={styles.intercessionTitle}>ظهر الغيب</Text>
          <Text style={styles.intercessionDesc}>ادعُ لأخيك في ظهر الغيب، ولك مثل ما دعوت به</Text>
        </View>
        <Pressable style={styles.intercessionBtn}>
          <Text style={styles.intercessionBtnText}>ادعُ الآن</Text>
        </Pressable>
      </View>

      {/* Quick Habits Card */}
      <View style={styles.habitsCard}>
        <Text style={styles.cardTitle}>حسنات النهاردة</Text>
        <Text style={styles.cardSubtitle}>عادات صغيرة، أجر كبير</Text>
        <View style={styles.habitsRow}>
          {quickHabits.map((habit) => {
            const done = completedHabits.includes(habit.id);
            return (
              <Pressable
                key={habit.id}
                onPress={() => toggleHabit(habit.id)}
                style={[styles.habitChip, done && styles.habitChipDone]}
              >
                <Text style={styles.habitEmoji}>{habit.icon}</Text>
                <Text style={[styles.habitLabel, done && styles.habitLabelDone]}>{habit.label}</Text>
                {done && <Text style={styles.checkMark}>✓</Text>}
              </Pressable>
            );
          })}
        </View>
      </View>

      {/* Community Tasbeeh Counter */}
      <View style={styles.tasbeehCard}>
        <View style={styles.tasbeehHeader}>
          <View>
            <Text style={styles.cardTitle}>مليونية التسبيح</Text>
            <Text style={styles.tasbeehDhikr}>سُبْحَانَ اللَّهِ وَبِحَمْدِهِ سُبْحَانَ اللَّهِ العَظِيمِ</Text>
          </View>
        </View>
        <View style={styles.tasbeehProgressWrap}>
          <View style={styles.tasbeehStatsRow}>
            <Text style={styles.tasbeehGlobalCount}>{(487200 + tasbeehCount).toLocaleString('ar-EG')}</Text>
            <Text style={styles.tasbeehTarget}>/ {tasbeehTarget.toLocaleString('ar-EG')}</Text>
          </View>
          <ProgressBar progress={tasbeehProgress} height={8} />
        </View>
        <View style={styles.tasbeehActions}>
          <Pressable
            style={styles.tasbeehButton}
            onPress={() => incrementTasbeeh(1)}
          >
            <Text style={styles.tasbeehBtnText}>سبّح (+1)</Text>
          </Pressable>
          <Pressable
            style={styles.tasbeehButtonSmall}
            onPress={() => incrementTasbeeh(10)}
          >
            <Text style={styles.tasbeehBtnTextSmall}>+10</Text>
          </Pressable>
          <Pressable
            style={styles.tasbeehButtonSmall}
            onPress={() => incrementTasbeeh(100)}
          >
            <Text style={styles.tasbeehBtnTextSmall}>+100</Text>
          </Pressable>
        </View>
        <View style={styles.tasbeehYourCount}>
          <Text style={styles.yourCountLabel}>تسبيحك اليوم:</Text>
          <Text style={styles.yourCountValue}>{tasbeehCount.toLocaleString('ar-EG')}</Text>
        </View>
        {/* Leaderboard */}
        <View style={styles.leaderboard}>
          <Text style={styles.leaderboardTitle}>أكثر المسبحين اليوم</Text>
          {tasbeehLeaderboard.map((leader) => (
            <View key={leader.rank} style={styles.leaderRow}>
              <Text style={styles.leaderRank}>{leader.rank}</Text>
              <Text style={styles.leaderEmoji}>{leader.avatar}</Text>
              <Text style={styles.leaderName}>{leader.name}</Text>
              <Text style={styles.leaderCount}>{leader.count.toLocaleString('ar-EG')}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Duel Widget */}
      <View style={styles.duelCard}>
        <View style={styles.duelLeft}>
          <Text style={styles.duelEmoji}>⚔️</Text>
          <View>
            <Text style={styles.duelTitle}>الغريم / التحدي</Text>
            <Text style={styles.duelDesc}>تحدّى صديقك في مسابقة القرآن</Text>
          </View>
        </View>
        <Pressable style={styles.duelBtn}>
          <Text style={styles.duelBtnText}>ابدأ التحدي</Text>
        </Pressable>
      </View>

      {/* Continue Reading */}
      {surah && (
        <View style={styles.continueCard}>
          <View style={styles.continueHeader}>
            <Text style={styles.cardTitle}>تابع القراءة</Text>
            <Pressable onPress={() => toggleFavorite(surah.number)}>
              <Text style={styles.bookmark}>⭐</Text>
            </Pressable>
          </View>
          <View style={styles.continueBody}>
            <View style={styles.surahInfo}>
              <Text style={styles.surahName}>{surah.name}</Text>
              <Text style={styles.surahMeta}>صفحة {currentPage} • {surah.revelationType} • {surah.ayahs} آية</Text>
            </View>
            <Pressable style={styles.playBtn}>
              <Text style={styles.playEmoji}>▶️</Text>
            </Pressable>
          </View>
          <View style={styles.continueProgress}>
            <ProgressBar progress={currentPage / 604} height={5} />
            <Text style={styles.progressLabel}>{Math.round((currentPage / 604) * 100)}% من المصحف</Text>
          </View>
        </View>
      )}

      {/* Shareable Quote Card */}
      <View style={styles.quoteCard}>
        <Text style={styles.quoteText}>{quote.text}</Text>
        <Text style={styles.quoteSource}>{quote.source}</Text>
        <Pressable style={styles.shareBtn}>
          <Text style={styles.shareBtnText}>شارك بطاقة</Text>
        </Pressable>
      </View>

      <View style={{ height: Spacing.xxl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg.primary,
  },
  content: {
    padding: Spacing.md,
    paddingTop: Spacing.xl + 8,
    gap: Spacing.md,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.xs,
  },
  greeting: { flex: 1 },
  salam: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  dateText: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  headerActions: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  headerIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.bg.tertiary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.border.subtle,
  },
  // Streak
  streakCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
  },
  streakLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  flameWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.overlay.goldGradient,
    alignItems: 'center',
    justifyContent: 'center',
  },
  streakTitle: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
  },
  streakCount: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[400],
    marginTop: 2,
  },
  // Prayer
  prayerCard: {
    backgroundColor: Colors.emerald[700],
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.emerald[600],
  },
  prayerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.lg,
  },
  hijriDate: {
    fontSize: Typography.sizes.xl,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[200],
  },
  gregDate: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
    marginTop: 2,
  },
  nextPrayerWrap: {
    alignItems: 'flex-end',
  },
  nextPrayerLabel: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
  },
  nextPrayerName: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  nextPrayerTime: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[200],
  },
  prayerTimesRow: {
    flexDirection: 'row',
    gap: Spacing.xs,
  },
  prayerTimeChip: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    borderRadius: Radius.md,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  prayerTimeChipActive: {
    backgroundColor: Colors.gold[400],
    borderColor: Colors.gold[400],
  },
  prayerEmoji: { fontSize: 16, marginBottom: 2 },
  prayerName: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.secondary,
  },
  prayerNameActive: {
    color: Colors.text.onGold,
  },
  prayerTime: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Tajawal-Bold',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  prayerTimeActive: {
    color: Colors.text.onGold,
  },
  // Intercession
  intercessionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
    gap: Spacing.md,
  },
  intercessionEmoji: { fontSize: 32 },
  intercessionBody: { flex: 1 },
  intercessionTitle: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[400],
  },
  intercessionDesc: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
    marginTop: 2,
    lineHeight: 1.4,
  },
  intercessionBtn: {
    backgroundColor: Colors.gold[400],
    borderRadius: Radius.pill,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
  },
  intercessionBtnText: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.onGold,
  },
  // Habits
  habitsCard: {
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
  },
  cardTitle: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  cardSubtitle: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  habitsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
    marginTop: Spacing.md,
  },
  habitChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: Radius.pill,
    backgroundColor: Colors.bg.tertiary,
    borderWidth: 1,
    borderColor: Colors.border.default,
  },
  habitChipDone: {
    backgroundColor: Colors.emerald[500],
    borderColor: Colors.emerald[400],
  },
  habitEmoji: { fontSize: 16 },
  habitLabel: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
  },
  habitLabelDone: {
    color: Colors.text.onEmerald,
    fontFamily: 'Cairo-Bold',
  },
  checkMark: {
    color: Colors.text.onEmerald,
    fontWeight: 'bold',
  },
  // Tasbeeh
  tasbeehCard: {
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.gold,
  },
  tasbeehHeader: { marginBottom: Spacing.md },
  tasbeehDhikr: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Amiri-Regular',
    color: Colors.gold[200],
    marginTop: 4,
    lineHeight: 1.6,
  },
  tasbeehProgressWrap: { marginBottom: Spacing.md },
  tasbeehStatsRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  tasbeehGlobalCount: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[400],
  },
  tasbeehTarget: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Regular',
    color: Colors.text.tertiary,
  },
  tasbeehActions: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  tasbeehButton: {
    flex: 1,
    backgroundColor: Colors.gold[400],
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    alignItems: 'center',
  },
  tasbeehBtnText: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.onGold,
  },
  tasbeehButtonSmall: {
    backgroundColor: Colors.bg.tertiary,
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border.default,
  },
  tasbeehBtnTextSmall: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[400],
  },
  tasbeehYourCount: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.border.subtle,
    marginBottom: Spacing.md,
  },
  yourCountLabel: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
  },
  yourCountValue: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[400],
  },
  leaderboard: {},
  leaderboardTitle: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.secondary,
    marginBottom: Spacing.sm,
  },
  leaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: 6,
  },
  leaderRank: {
    width: 20,
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Bold',
    color: Colors.text.tertiary,
    textAlign: 'center',
  },
  leaderEmoji: { fontSize: 20 },
  leaderName: {
    flex: 1,
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.primary,
  },
  leaderCount: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[300],
  },
  // Duel
  duelCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
    gap: Spacing.md,
  },
  duelLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flex: 1 },
  duelEmoji: { fontSize: 32 },
  duelTitle: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  duelDesc: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  duelBtn: {
    backgroundColor: Colors.emerald[500],
    borderRadius: Radius.pill,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
  },
  duelBtnText: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.onEmerald,
  },
  // Continue Reading
  continueCard: {
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
  },
  continueHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bookmark: { fontSize: 20 },
  continueBody: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: Spacing.md,
  },
  surahInfo: { flex: 1 },
  surahName: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Amiri-Bold',
    color: Colors.gold[200],
  },
  surahMeta: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  playBtn: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.gold[400],
    alignItems: 'center',
    justifyContent: 'center',
  },
  playEmoji: { fontSize: 18 },
  continueProgress: { marginTop: Spacing.md },
  progressLabel: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: Spacing.xs,
  },
  // Quote
  quoteCard: {
    backgroundColor: Colors.emerald[800],
    borderRadius: Radius.lg,
    padding: Spacing.xl,
    borderWidth: 1,
    borderColor: Colors.emerald[600],
    alignItems: 'center',
  },
  quoteText: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Amiri-Bold',
    color: Colors.gold[200],
    textAlign: 'center',
    lineHeight: 1.8,
  },
  quoteSource: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
    marginTop: Spacing.sm,
  },
  shareBtn: {
    marginTop: Spacing.lg,
    backgroundColor: Colors.gold[400],
    borderRadius: Radius.pill,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.xl,
  },
  shareBtnText: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.onGold,
  },
});
