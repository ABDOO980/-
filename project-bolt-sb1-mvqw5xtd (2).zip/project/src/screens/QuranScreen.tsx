import { useState, useMemo } from 'react';
import { View, StyleSheet, Text, ScrollView, Pressable, FlatList } from 'react-native';
import { Flame, Bookmark, Play, BookOpen } from 'lucide-react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';
import { surahs, Surah } from '@/src/data/surahs';
import { useAppStore } from '@/src/store/useAppStore';
import { Chip, SearchBar, ProgressBar } from '@/src/components/ui';

type FilterType = 'all' | 'memorize' | 'ward' | 'favorites' | 'search';

export function QuranScreen() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');
  const { favoriteSurahs, toggleFavorite, currentSurah, currentPage } = useAppStore();

  const currentSurahData = surahs.find((s) => s.number === currentSurah);

  const filteredSurahs = useMemo(() => {
    let result = surahs;
    if (filter === 'favorites') {
      result = result.filter((s) => favoriteSurahs.includes(s.number));
    }
    if (search.trim()) {
      const q = search.trim();
      result = result.filter(
        (s) => s.name.includes(q) || s.englishName.toLowerCase().includes(q.toLowerCase()) || s.number.toString() === q
      );
    }
    return result;
  }, [search, filter, favoriteSurahs]);

  const filters: { key: FilterType; label: string }[] = [
    { key: 'memorize', label: 'المحفّظ' },
    { key: 'ward', label: 'وردي' },
    { key: 'favorites', label: 'المفضلة' },
    { key: 'search', label: 'بحث الآيات' },
  ];

  const renderSurah = ({ item }: { item: Surah }) => {
    const isFavorite = favoriteSurahs.includes(item.number);
    const isCurrent = item.number === currentSurah;

    return (
      <Pressable style={({ pressed }) => [styles.surahRow, pressed && styles.pressed]}>
        <View style={styles.surahIndexWrap}>
          <View style={[styles.surahIndexCircle, isCurrent && styles.surahIndexCircleActive]}>
            <Text style={[styles.surahIndex, isCurrent && styles.surahIndexActive]}>{item.number}</Text>
          </View>
        </View>
        <View style={styles.surahInfo}>
          <View style={styles.surahNameRow}>
            <Text style={styles.surahName}>{item.name}</Text>
            {isFavorite && <Bookmark size={14} color={Colors.gold[400]} strokeWidth={2} fill={Colors.gold[400]} />}
          </View>
          <View style={styles.surahMetaRow}>
            <View style={styles.metaChip}>
              <Text style={styles.metaText}>{item.revelationType}</Text>
            </View>
            <Text style={styles.metaSep}>•</Text>
            <Text style={styles.metaText}>{item.ayahs} آية</Text>
            <Text style={styles.metaSep}>•</Text>
            <Text style={styles.metaText}>صفحة {item.page}</Text>
            <Text style={styles.metaSep}>•</Text>
            <Text style={styles.metaText}>جزء {item.juz}</Text>
          </View>
        </View>
        <View style={styles.surahActions}>
          {item.ayahs > 100 && (
            <View style={styles.flameBadge}>
              <Flame size={12} color={Colors.gold[400]} strokeWidth={2} />
            </View>
          )}
          <Pressable onPress={() => toggleFavorite(item.number)} hitSlop={8}>
            <Bookmark
              size={18}
              color={isFavorite ? Colors.gold[400] : Colors.text.muted}
              strokeWidth={2}
              fill={isFavorite ? Colors.gold[400] : 'transparent'}
            />
          </Pressable>
        </View>
      </Pressable>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.screenTitle}>المصحف</Text>
        <Text style={styles.screenSubtitle}>{filteredSurahs.length} سورة</Text>
      </View>

      <View style={styles.searchWrap}>
        <SearchBar
          value={search}
          onChangeText={setSearch}
          placeholder="ابحث عن سورة أو آية..."
        />
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filtersRow}>
        {filters.map((f) => (
          <Chip
            key={f.key}
            label={f.label}
            active={filter === f.key}
            onPress={() => setFilter(f.key)}
          />
        ))}
      </ScrollView>

      {/* Continue Reading Banner */}
      {currentSurahData && (
        <View style={styles.continueBanner}>
          <View style={styles.continueLeft}>
            <View style={styles.continueIcon}>
              <BookOpen size={20} color={Colors.gold[400]} strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.continueTitle}>تابع القراءة</Text>
              <Text style={styles.continueMeta}>
                {currentSurahData.name} • صفحة {currentPage}
              </Text>
            </View>
          </View>
          <View style={styles.continueRight}>
            <Pressable style={styles.playBtn}>
              <Play size={16} color={Colors.text.onGold} strokeWidth={2} fill={Colors.text.onGold} />
            </Pressable>
            <View style={styles.continueProgress}>
              <ProgressBar progress={currentPage / 604} height={4} />
            </View>
          </View>
        </View>
      )}

      <FlatList
        data={filteredSurahs}
        keyExtractor={(item) => item.number.toString()}
        renderItem={renderSurah}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg.primary,
  },
  header: {
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.xl + 8,
    paddingBottom: Spacing.sm,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  screenTitle: {
    fontSize: Typography.sizes.xxxl,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  screenSubtitle: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.gold[400],
  },
  searchWrap: {
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
  },
  filtersRow: {
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.md,
  },
  continueBanner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: Colors.emerald[700],
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.emerald[600],
  },
  continueLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    flex: 1,
  },
  continueIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(212,175,55,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  continueTitle: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[200],
  },
  continueMeta: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
    marginTop: 2,
  },
  continueRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  playBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.gold[400],
    alignItems: 'center',
    justifyContent: 'center',
  },
  continueProgress: {
    width: 80,
  },
  list: {
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.xxl,
  },
  surahRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    gap: Spacing.md,
  },
  pressed: {
    opacity: 0.7,
  },
  surahIndexWrap: {},
  surahIndexCircle: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: Colors.bg.tertiary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.border.subtle,
  },
  surahIndexCircleActive: {
    backgroundColor: Colors.gold[400],
    borderColor: Colors.gold[400],
  },
  surahIndex: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Bold',
    color: Colors.text.secondary,
  },
  surahIndexActive: {
    color: Colors.text.onGold,
  },
  surahInfo: {
    flex: 1,
  },
  surahNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  surahName: {
    fontSize: Typography.sizes.xl,
    fontFamily: 'Amiri-Bold',
    color: Colors.text.primary,
  },
  surahMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  metaChip: {
    backgroundColor: Colors.emerald[800],
    borderRadius: Radius.xs,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  metaText: {
    fontSize: 10,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
  },
  metaSep: {
    fontSize: 10,
    color: Colors.text.muted,
  },
  surahActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  flameBadge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.overlay.goldGradient,
    alignItems: 'center',
    justifyContent: 'center',
  },
  separator: {
    height: 1,
    backgroundColor: Colors.border.subtle,
  },
});
