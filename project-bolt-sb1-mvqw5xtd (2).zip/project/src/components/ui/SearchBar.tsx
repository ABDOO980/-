import { ReactNode } from 'react';
import { View, StyleSheet, TextInput, Pressable } from 'react-native';
import { Search, X } from 'lucide-react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';

interface SearchBarProps {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  onSubmit?: () => void;
  rightIcon?: ReactNode;
}

export function SearchBar({ value, onChangeText, placeholder = 'بحث...', onSubmit, rightIcon }: SearchBarProps) {
  return (
    <View style={styles.container}>
      <Search size={20} color={Colors.text.tertiary} strokeWidth={2} />
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={Colors.text.muted}
        onSubmitEditing={onSubmit}
        returnKeyType="search"
        textAlign="right"
      />
      {value.length > 0 ? (
        <Pressable onPress={() => onChangeText('')} hitSlop={8}>
          <X size={18} color={Colors.text.tertiary} strokeWidth={2} />
        </Pressable>
      ) : (
        rightIcon
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bg.tertiary,
    borderRadius: Radius.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm + 2,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
    gap: Spacing.sm,
  },
  input: {
    flex: 1,
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.primary,
    padding: 0,
  },
});
