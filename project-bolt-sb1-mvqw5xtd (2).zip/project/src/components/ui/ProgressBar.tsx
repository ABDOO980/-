import { View, StyleSheet } from 'react-native';
import { Colors } from '@/src/theme';

interface ProgressBarProps {
  progress: number;
  height?: number;
  color?: string;
  bgColor?: string;
  borderRadius?: number;
}

export function ProgressBar({
  progress,
  height = 6,
  color = Colors.gold[400],
  bgColor = Colors.border.default,
  borderRadius = 999,
}: ProgressBarProps) {
  const clamped = Math.min(Math.max(progress, 0), 1);

  return (
    <View style={[styles.container, { height, borderRadius, backgroundColor: bgColor }]}>
      <View
        style={[
          styles.fill,
          {
            width: `${clamped * 100}%`,
            backgroundColor: color,
            borderRadius,
          },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    overflow: 'hidden',
  },
  fill: {
    height: '100%',
  },
});
