import { ReactNode } from 'react';
import { View, StyleSheet, Pressable, Text } from 'react-native';
import { ChevronLeft } from 'lucide-react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
  icon?: ReactNode;
}

export function SectionHeader({ title, subtitle, actionLabel, onAction, icon }: SectionHeaderProps) {
  return (
    <View style={styles.container}>
      <View style={styles.left}>
        {icon && <View style={styles.iconWrap}>{icon}</View>}
        <View>
          <Text style={styles.title}>{title}</Text>
          {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
        </View>
      </View>
      {actionLabel && (
        <Pressable onPress={onAction} style={({ pressed }) => [styles.action, pressed && styles.pressed]}>
          <Text style={styles.actionLabel}>{actionLabel}</Text>
          <ChevronLeft size={16} color={Colors.gold[400]} strokeWidth={2} />
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
  },
  left: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    flex: 1,
  },
  iconWrap: {},
  title: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  subtitle: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  action: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  actionLabel: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.gold[400],
  },
  pressed: {
    opacity: 0.7,
  },
});
