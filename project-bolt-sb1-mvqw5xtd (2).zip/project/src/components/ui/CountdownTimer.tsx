import { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';
import { formatCountdown } from '@/src/data/prayers';

interface CountdownTimerProps {
  seconds: number;
  label?: string;
  onTick?: (remaining: number) => void;
}

export function CountdownTimer({ seconds, label }: CountdownTimerProps) {
  const [remaining, setRemaining] = useState(seconds);

  useEffect(() => {
    setRemaining(seconds);
  }, [seconds]);

  useEffect(() => {
    const interval = setInterval(() => {
      setRemaining((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <View style={styles.container}>
      {label && <Text style={styles.label}>{label}</Text>}
      <Text style={styles.timer}>{formatCountdown(remaining)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'flex-start',
  },
  label: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginBottom: 2,
  },
  timer: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[400],
    fontVariant: ['tabular-nums'],
  },
});
