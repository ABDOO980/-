import { ReactNode } from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { Colors, Spacing, Radius, Shadows } from '@/src/theme';

interface CardProps {
  children: ReactNode;
  style?: ViewStyle | ViewStyle[];
  gradient?: 'gold' | 'emerald' | 'none';
  onPress?: () => void;
}

export function Card({ children, style, gradient = 'none' }: CardProps) {
  const gradientBg = {
    gold: Colors.overlay.goldGradient,
    emerald: Colors.overlay.emeraldGradient,
    none: 'transparent',
  };

  return (
    <View style={[styles.card, style]}>
      <View style={[styles.gradientOverlay, { backgroundColor: gradientBg[gradient] }]} />
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
    overflow: 'hidden',
    ...Shadows.sm,
  },
  gradientOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
});
