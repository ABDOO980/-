import { ReactNode } from 'react';
import { View, StyleSheet, Pressable, ViewStyle } from 'react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';

interface ChipProps {
  label: string;
  active?: boolean;
  onPress?: () => void;
  icon?: ReactNode;
  style?: ViewStyle;
}

export function Chip({ label, active, onPress, icon, style }: ChipProps) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.chip,
        active ? styles.chipActive : styles.chipInactive,
        pressed && styles.pressed,
        style,
      ]}
    >
      {icon && <View style={styles.iconWrap}>{icon}</View>}
      <Text style={[styles.label, active ? styles.labelActive : styles.labelInactive]}>
        {label}
      </Text>
    </Pressable>
  );
}

import { Text } from 'react-native';

const styles = StyleSheet.create({
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: Radius.pill,
    borderWidth: 1,
    gap: Spacing.xs,
  },
  chipActive: {
    backgroundColor: Colors.gold[400],
    borderColor: Colors.gold[400],
  },
  chipInactive: {
    backgroundColor: Colors.bg.tertiary,
    borderColor: Colors.border.default,
  },
  label: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Bold',
  },
  labelActive: {
    color: Colors.text.onGold,
  },
  labelInactive: {
    color: Colors.text.secondary,
  },
  iconWrap: {},
  pressed: {
    opacity: 0.85,
    transform: [{ scale: 0.97 }],
  },
});
