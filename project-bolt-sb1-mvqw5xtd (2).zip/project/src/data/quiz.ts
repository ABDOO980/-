export interface QuizQuestion {
  id: string;
  category: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: 'q1',
    category: 'القرآن الكريم',
    question: 'كم عدد سور القرآن الكريم؟',
    options: ['110', '114', '120', '99'],
    correctIndex: 1,
    explanation: 'عدد سور القرآن الكريم 114 سورة',
  },
  {
    id: 'q2',
    category: 'القرآن الكريم',
    question: 'ما أطول سورة في القرآن الكريم؟',
    options: ['آل عمران', 'النساء', 'البقرة', 'المائدة'],
    correctIndex: 2,
    explanation: 'سورة البقرة هي أطول سورة في القرآن الكريم بـ 286 آية',
  },
  {
    id: 'q3',
    category: 'القرآن الكريم',
    question: 'ما أقصر سورة في القرآن الكريم؟',
    options: ['الإخلاص', 'الكوثر', 'الفلق', 'العصر'],
    correctIndex: 1,
    explanation: 'سورة الكوثر هي أقصر سورة بـ 3 آيات',
  },
  {
    id: 'q4',
    category: 'الفقه',
    question: 'كم عدد ركعات صلاة الفجر؟',
    options: ['2', '3', '4', '5'],
    correctIndex: 0,
    explanation: 'صلاة الفجر ركعتان',
  },
  {
    id: 'q5',
    category: 'الفقه',
    question: 'كم عدد ركعات صلاة الظهر؟',
    options: ['2', '3', '4', '5'],
    correctIndex: 2,
    explanation: 'صلاة الظهر أربع ركعات',
  },
  {
    id: 'q6',
    category: 'الفقه',
    question: 'كم عدد ركعات صلاة المغرب؟',
    options: ['2', '3', '4', '5'],
    correctIndex: 1,
    explanation: 'صلاة المغرب ثلاث ركعات',
  },
  {
    id: 'q7',
    category: 'السيرة',
    question: 'في أي عام هاجر النبي ﷺ إلى المدينة؟',
    options: ['العام 10 من البعثة', 'العام 13 من البعثة', 'العام 15 من البعثة', 'العام 5 من البعثة'],
    correctIndex: 1,
    explanation: 'هاجر النبي ﷺ في العام 13 من البعثة',
  },
  {
    id: 'q8',
    category: 'القرآن الكريم',
    question: 'في أي سورة توجد آية الكرسي؟',
    options: ['آل عمران', 'البقرة', 'النساء', 'الفاتحة'],
    correctIndex: 1,
    explanation: 'آية الكرسي هي الآية 255 من سورة البقرة',
  },
  {
    id: 'q9',
    category: 'القرآن الكريم',
    question: 'كم عدد أجزاء القرآن الكريم؟',
    options: ['20', '25', '30', '60'],
    correctIndex: 2,
    explanation: 'القرآن الكريم مقسم إلى 30 جزءاً',
  },
  {
    id: 'q10',
    category: 'الفقه',
    question: 'ما هو عدد أشهر الحج؟',
    options: ['شهر واحد', 'شهران', 'ثلاثة أشهر', 'أربعة أشهر'],
    correctIndex: 1,
    explanation: 'أشهر الحج هي شوال وذو القعدة وذو الحجة (ثلاثة أشهر)',
  },
  {
    id: 'q11',
    category: 'العقيدة',
    question: 'كم عدد أركان الإسلام؟',
    options: ['3', '5', '6', '7'],
    correctIndex: 1,
    explanation: 'أركان الإسلام خمسة: الشهادتان، الصلاة، الزكاة، الصوم، الحج',
  },
  {
    id: 'q12',
    category: 'العقيدة',
    question: 'كم عدد أركان الإيمان؟',
    options: ['5', '6', '7', '8'],
    correctIndex: 1,
    explanation: 'أركان الإيمان ستة: الإيمان بالله وملائكته وكتبه ورسله واليوم الآخر والقدر',
  },
  {
    id: 'q13',
    category: 'السيرة',
    question: 'ما اسم أم النبي محمد ﷺ؟',
    options: ['خديجة', 'آمنة', 'فاطمة', 'حليمة'],
    correctIndex: 1,
    explanation: 'اسم أم النبي ﷺ آمنة بنت وهب',
  },
  {
    id: 'q14',
    category: 'القرآن الكريم',
    question: 'ما السورة التي تعدل ثلث القرآن؟',
    options: ['الفاتحة', 'الإخلاص', 'الكوثر', 'الناس'],
    correctIndex: 1,
    explanation: 'سورة الإخلاص تعدل ثلث القرآن كما ورد في الحديث',
  },
  {
    id: 'q15',
    category: 'الفقه',
    question: 'ما عدد أيام صيام شهر رمضان عادةً؟',
    options: ['28', '29 أو 30', '31', '27'],
    correctIndex: 1,
    explanation: 'شهر رمضان يكون 29 أو 30 يوماً حسب رؤية الهلال',
  },
];

export interface SituationalPrayer {
  id: string;
  title: string;
  text: string;
  reference: string;
}

export const situationalPrayers: SituationalPrayer[] = [
  { id: 'sp1', title: 'دعاء دخول الخلاء', text: 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ', reference: 'رواه البخاري' },
  { id: 'sp2', title: 'دعاء الخروج من الخلاء', text: 'غُفْرَانَكَ', reference: 'رواه أبو داود' },
  { id: 'sp3', title: 'دعاء قبل الطعام', text: 'اللَّهُمَّ بَارِكْ لَنَا فِيمَا رَزَقْتَنَا وَقِنَا عَذَابَ النَّارِ', reference: 'رواه أبو داود' },
  { id: 'sp4', title: 'دعاء بعد الطعام', text: 'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ', reference: 'رواه الترمذي' },
  { id: 'sp5', title: 'دعاء دخول المسجد', text: 'اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ', reference: 'رواه مسلم' },
  { id: 'sp6', title: 'دعاء الخروج من المسجد', text: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ', reference: 'رواه مسلم' },
  { id: 'sp7', title: 'دعاء السفر', text: 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ', reference: 'رواه مسلم' },
  { id: 'sp8', title: 'دعاء الكرب', text: 'لَا إِلَهَ إِلَّا اللَّهُ العَظِيمُ الحَلِيمُ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ العَرْشِ العَظِيمِ', reference: 'رواه البخاري' },
];
