export interface PrayerTime {
  key: string;
  name: string;
  icon: string;
  time: string;
}

export function getPrayerTimes(): PrayerTime[] {
  return [
    { key: 'fajr', name: 'الفجر', icon: 'sunrise', time: '04:32' },
    { key: 'sunrise', name: 'الشروق', icon: 'sun', time: '06:05' },
    { key: 'dhuhr', name: 'الظهر', icon: 'sun-medium', time: '12:18' },
    { key: 'asr', name: 'العصر', icon: 'cloud-sun', time: '15:45' },
    { key: 'maghrib', name: 'المغرب', icon: 'sunset', time: '18:32' },
    { key: 'isha', name: 'العشاء', icon: 'moon', time: '20:05' },
  ];
}

export function getNextPrayer(): { name: string; time: string; remainingSeconds: number } {
  const prayers = getPrayerTimes();
  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();

  for (const prayer of prayers) {
    const [h, m] = prayer.time.split(':').map(Number);
    const prayerMinutes = h * 60 + m;
    if (prayerMinutes > nowMinutes) {
      const remainingSeconds = (prayerMinutes - nowMinutes) * 60 - now.getSeconds();
      return { name: prayer.name, time: prayer.time, remainingSeconds };
    }
  }
  const [h, m] = prayers[0].time.split(':').map(Number);
  const remainingSeconds = (24 * 60 - nowMinutes + h * 60 + m) * 60 - now.getSeconds();
  return { name: prayers[0].name, time: prayers[0].time, remainingSeconds };
}

export function formatCountdown(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

const hijriMonths = [
  'محرم', 'صفر', 'ربيع الأول', 'ربيع الثاني', 'جمادى الأولى', 'جمادى الآخرة',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة',
];

export function getHijriDate(): string {
  const now = new Date();
  const approxHijriDay = ((now.getDate() + 1) % 30) || 1;
  const approxHijriMonth = (now.getMonth()) % 12;
  return `${approxHijriDay} ${hijriMonths[approxHijriMonth]} ${now.getFullYear() - 579} هـ`;
}

export function getGregorianDate(): string {
  const now = new Date();
  const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  return `${days[now.getDay()]}، ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
}
