export interface IslamicQuote {
  id: string;
  text: string;
  source: string;
  type: 'verse' | 'hadith' | 'quote';
}

export const islamicQuotes: IslamicQuote[] = [
  { id: '1', text: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا', source: 'سورة الشرح - الآية 6', type: 'verse' },
  { id: '2', text: 'وَقُل رَّبِّ زِدْنِي عِلْمًا', source: 'سورة طه - الآية 114', type: 'verse' },
  { id: '3', text: 'اللَّهُمَّ اجْعَلْنِي أَخْشَاكَ حَتَّى كَأَنِّي أَرَاكَ', source: 'دعاء النبي ﷺ', type: 'hadith' },
  { id: '4', text: 'إِنَّ اللَّهَ لَا يُغَيِّرُ مَا بِقَوْمٍ حَتَّى يُغَيِّرُوا مَا بِأَنفُسِهِمْ', source: 'سورة الرعد - الآية 11', type: 'verse' },
  { id: '5', text: 'مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ طَرِيقًا إِلَى الْجَنَّةِ', source: 'رواه مسلم', type: 'hadith' },
  { id: '6', text: 'وَبَشِّرِ الصَّابِرِينَ', source: 'سورة البقرة - الآية 155', type: 'verse' },
  { id: '7', text: 'خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ', source: 'رواه البخاري', type: 'hadith' },
  { id: '8', text: 'وَأَن لَّيْسَ لِلْإِنسَانِ إِلَّا مَا سَعَىٰ', source: 'سورة النجم - الآية 39', type: 'verse' },
];

export interface TasbeehLeader {
  rank: number;
  name: string;
  count: number;
  avatar: string;
}

export const tasbeehLeaderboard: TasbeehLeader[] = [
  { rank: 1, name: 'أبو عبدالله', count: 12450, avatar: '🌟' },
  { rank: 2, name: 'أم محمد', count: 11200, avatar: '🌙' },
  { rank: 3, name: 'خالد الأنصاري', count: 9800, avatar: '⭐' },
  { rank: 4, name: 'فاطمة الزهراء', count: 8650, avatar: '🌸' },
  { rank: 5, name: 'عبدالرحمن', count: 7200, avatar: '✨' },
];

export interface WeeklyChampion {
  rank: number;
  name: string;
  score: number;
  league: string;
}

export const weeklyChampions: WeeklyChampion[] = [
  { rank: 1, name: 'محمد الإسكندري', score: 9850, league: 'الذهبية' },
  { rank: 2, name: 'سارة الأنصارية', score: 9200, league: 'الذهبية' },
  { rank: 3, name: 'يوسف العامري', score: 8700, league: 'الذهبية' },
  { rank: 4, name: 'عائشة الفاضل', score: 8100, league: 'الذهبية' },
  { rank: 5, name: 'إبراهيم المهندس', score: 7650, league: 'الذهبية' },
  { rank: 6, name: 'مريم الخبيرة', score: 7200, league: 'الفضية' },
  { rank: 7, name: 'عبدالله الراشد', score: 6800, league: 'الفضية' },
  { rank: 8, name: 'نورا السالم', score: 6300, league: 'الفضية' },
];
