import { QuranScreen } from '@/src/screens/QuranScreen';

export default function QuranTab() {
  return <QuranScreen />;
}
