import { View, StyleSheet, Text, ScrollView, Pressable } from 'react-native';
import { Users, Gift, Crown, Share2, Award, TrendingUp } from 'lucide-react-native';
import { Colors, Spacing, Radius, Typography } from '@/src/theme';
import { weeklyChampions } from '@/src/data/content';
import { useAppStore } from '@/src/store/useAppStore';

export default function AmbassadorsTab() {
  const { quizScore } = useAppStore();

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Text style={styles.screenTitle}>سفراء يقين</Text>
        <Text style={styles.screenSubtitle}>ادعُ، شارك، وتصدّر</Text>
      </View>

      {/* Referral Hero Card */}
      <View style={styles.heroCard}>
        <View style={styles.heroIconWrap}>
          <Gift size={32} color={Colors.gold[400]} strokeWidth={2} />
        </View>
        <Text style={styles.heroTitle}>برنامج السفراء</Text>
        <Text style={styles.heroDesc}>
          ادعُ أصدقاءك إلى الخير، واكسب النقاط مع كل دعوة ناجحة. تصلك شارة "سفير يقين" عند دعوة 10 أصدقاء.
        </Text>
        <View style={styles.heroStatsRow}>
          <View style={styles.heroStat}>
            <Text style={styles.heroStatValue}>7</Text>
            <Text style={styles.heroStatLabel}>دعوات</Text>
          </View>
          <View style={styles.heroDivider} />
          <View style={styles.heroStat}>
            <Text style={styles.heroStatValue}>350</Text>
            <Text style={styles.heroStatLabel}>نقطة</Text>
          </View>
          <View style={styles.heroDivider} />
          <View style={styles.heroStat}>
            <Text style={styles.heroStatValue}>{quizScore}</Text>
            <Text style={styles.heroStatLabel}>إجمالي</Text>
          </View>
        </View>
        <Pressable style={styles.inviteBtn}>
          <Share2 size={18} color={Colors.text.onGold} strokeWidth={2} />
          <Text style={styles.inviteBtnText}>شارك رابط الدعوة</Text>
        </Pressable>
      </View>

      {/* Your League */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Crown size={18} color={Colors.gold[400]} strokeWidth={2} />
          <Text style={styles.sectionTitle}>دوري الأسبوع</Text>
        </View>
        <View style={styles.leagueCard}>
          <View style={styles.leagueBadgeLarge}>
            <Award size={28} color={Colors.gold[300]} strokeWidth={2} />
            <Text style={styles.leagueName}>الذهبية</Text>
          </View>
          <View style={styles.leagueInfo}>
            <Text style={styles.leagueRank}>المركز 12</Text>
            <Text style={styles.leaguePoints}>{quizScore} نقطة</Text>
            <Text style={styles.leagueProgress}>3 نقاط للترقية للدوري الماسي</Text>
          </View>
          <TrendingUp size={24} color={Colors.success} strokeWidth={2} />
        </View>
      </View>

      {/* Top Ambassadors */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Users size={18} color={Colors.gold[400]} strokeWidth={2} />
          <Text style={styles.sectionTitle}>أكثر السفراء دعوة</Text>
        </View>
        <View style={styles.leaderboardCard}>
          {weeklyChampions.map((champ) => (
            <View key={champ.rank} style={styles.leaderRow}>
              <View style={[
                styles.rankBadge,
                champ.rank === 1 && styles.rankGold,
                champ.rank === 2 && styles.rankSilver,
                champ.rank === 3 && styles.rankBronze,
              ]}>
                <Text style={styles.rankText}>{champ.rank}</Text>
              </View>
              <Text style={styles.leaderEmoji}>
                {champ.rank === 1 ? '👑' : champ.rank === 2 ? '🥈' : champ.rank === 3 ? '🥉' : '⭐'}
              </Text>
              <View style={styles.leaderInfo}>
                <Text style={styles.leaderName}>{champ.name}</Text>
                <Text style={styles.leaderLeague}>{champ.league}</Text>
              </View>
              <View style={styles.leaderStats}>
                <Text style={styles.leaderInvites}>{champ.score.toLocaleString('ar-EG')}</Text>
                <Text style={styles.leaderInvitesLabel}>دعوة</Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      {/* Badges */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Award size={18} color={Colors.gold[400]} strokeWidth={2} />
          <Text style={styles.sectionTitle}>أوسمتك</Text>
        </View>
        <View style={styles.badgesRow}>
          {[
            { emoji: '🌟', label: 'بداية الرحلة', earned: true },
            { emoji: '📖', label: 'قارئ نشط', earned: true },
            { emoji: '🤲', label: 'ذاكر', earned: true },
            { emoji: '🏆', label: 'بطل الجمعة', earned: false },
            { emoji: '👑', label: 'سفير يقين', earned: false },
            { emoji: '💎', label: 'الدوري الماسي', earned: false },
          ].map((badge) => (
            <View key={badge.label} style={[styles.badge, !badge.earned && styles.badgeLocked]}>
              <Text style={[styles.badgeEmoji, !badge.earned && styles.badgeEmojiLocked]}>
                {badge.earned ? badge.emoji : '🔒'}
              </Text>
              <Text style={[styles.badgeLabel, !badge.earned && styles.badgeLabelLocked]}>
                {badge.label}
              </Text>
            </View>
          ))}
        </View>
      </View>

      <View style={{ height: Spacing.xxl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg.primary },
  content: { padding: Spacing.md, paddingTop: Spacing.xl + 8, gap: Spacing.lg },
  header: { marginBottom: Spacing.xs },
  screenTitle: {
    fontSize: Typography.sizes.xxxl,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  screenSubtitle: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.gold[400],
    marginTop: 2,
  },
  // Hero
  heroCard: {
    backgroundColor: Colors.emerald[700],
    borderRadius: Radius.xl,
    padding: Spacing.xl,
    borderWidth: 1,
    borderColor: Colors.emerald[600],
    alignItems: 'center',
  },
  heroIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(212,175,55,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  heroTitle: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[200],
    marginBottom: Spacing.sm,
  },
  heroDesc: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.secondary,
    textAlign: 'center',
    lineHeight: 1.6,
    marginBottom: Spacing.lg,
  },
  heroStatsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  heroStat: { alignItems: 'center', paddingHorizontal: Spacing.md },
  heroStatValue: {
    fontSize: Typography.sizes.xxl,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[400],
  },
  heroStatLabel: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  heroDivider: { width: 1, height: 30, backgroundColor: Colors.border.subtle },
  inviteBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.gold[400],
    borderRadius: Radius.pill,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xl,
  },
  inviteBtnText: {
    fontSize: Typography.sizes.md,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.onGold,
  },
  // Sections
  section: {},
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[400],
  },
  // League
  leagueCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.gold,
    gap: Spacing.md,
  },
  leagueBadgeLarge: {
    alignItems: 'center',
    gap: 4,
  },
  leagueName: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[300],
  },
  leagueInfo: { flex: 1 },
  leagueRank: {
    fontSize: Typography.sizes.lg,
    fontFamily: 'Cairo-Bold',
    color: Colors.text.primary,
  },
  leaguePoints: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[400],
    marginTop: 2,
  },
  leagueProgress: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  // Leaderboard
  leaderboardCard: {
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border.subtle,
  },
  leaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.sm,
  },
  rankBadge: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: Colors.bg.tertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankGold: { backgroundColor: Colors.gold[400] },
  rankSilver: { backgroundColor: '#C0C0C0' },
  rankBronze: { backgroundColor: '#CD7F32' },
  rankText: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Bold',
    color: Colors.text.primary,
  },
  leaderEmoji: { fontSize: 20 },
  leaderInfo: { flex: 1 },
  leaderName: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.primary,
  },
  leaderLeague: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.tertiary,
    marginTop: 2,
  },
  leaderStats: { alignItems: 'flex-end' },
  leaderInvites: {
    fontSize: Typography.sizes.sm,
    fontFamily: 'Tajawal-Bold',
    color: Colors.gold[300],
  },
  leaderInvitesLabel: {
    fontSize: 10,
    fontFamily: 'Cairo-Regular',
    color: Colors.text.muted,
  },
  // Badges
  badgesRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  badge: {
    width: '31%',
    alignItems: 'center',
    backgroundColor: Colors.bg.card,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border.gold,
    gap: Spacing.xs,
  },
  badgeLocked: {
    borderColor: Colors.border.subtle,
    opacity: 0.5,
  },
  badgeEmoji: { fontSize: 32 },
  badgeEmojiLocked: { fontSize: 24 },
  badgeLabel: {
    fontSize: Typography.sizes.xs,
    fontFamily: 'Cairo-Bold',
    color: Colors.gold[300],
    textAlign: 'center',
  },
  badgeLabelLocked: {
    color: Colors.text.muted,
  },
});
