import { Tabs } from 'expo-router';
import {
  Home, BookOpen, HandsPraying, Trophy, Users, MoreHorizontal,
} from 'lucide-react-native';
import { Colors } from '@/src/theme';
import { Spacing } from '@/src/theme';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: Colors.bg.secondary,
          borderTopColor: Colors.border.subtle,
          borderTopWidth: 1,
          height: 64,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarActiveTintColor: Colors.gold[400],
        tabBarInactiveTintColor: Colors.text.muted,
        tabBarLabelStyle: {
          fontFamily: 'Cairo-Regular',
          fontSize: 11,
          marginTop: 2,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'الرئيسية',
          tabBarIcon: ({ size, color }) => (
            <Home size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
      <Tabs.Screen
        name="quran"
        options={{
          title: 'المصحف',
          tabBarIcon: ({ size, color }) => (
            <BookOpen size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
      <Tabs.Screen
        name="adhkar"
        options={{
          title: 'الأذكار',
          tabBarIcon: ({ size, color }) => (
            <HandsPraying size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
      <Tabs.Screen
        name="quiz"
        options={{
          title: 'مسابقة',
          tabBarIcon: ({ size, color }) => (
            <Trophy size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
      <Tabs.Screen
        name="ambassadors"
        options={{
          title: 'السفراء',
          tabBarIcon: ({ size, color }) => (
            <Users size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
      <Tabs.Screen
        name="more"
        options={{
          title: 'المزيد',
          tabBarIcon: ({ size, color }) => (
            <MoreHorizontal size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
    </Tabs>
  );
}
