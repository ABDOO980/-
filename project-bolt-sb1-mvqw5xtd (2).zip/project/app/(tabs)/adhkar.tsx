import { AdhkarScreen } from '@/src/screens/AdhkarScreen';

export default function AdhkarTab() {
  return <AdhkarScreen />;
}
