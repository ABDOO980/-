import { QuizScreen } from '@/src/screens/QuizScreen';

export default function QuizTab() {
  return <QuizScreen />;
}
